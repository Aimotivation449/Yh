let billClaims = [];
let currentEditIndex = -1;

// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    loadBillClaims();
    renderBillClaimsTable();

    // Add event listener for regiment number input
    document.getElementById('regtNo').addEventListener('blur', function() {
        const regtNo = this.value.trim();
        if (regtNo) {
            // Get employee data from localStorage
            const salaryData = DataManager.loadSalaryData();
            if (salaryData && salaryData.employees) {
                const employee = salaryData.employees.find(emp => emp.regtNo === regtNo);
                if (employee) {
                    document.getElementById('name').value = employee.name || '';
                    document.getElementById('rank').value = employee.rank || '';
                }
            }
        }
    });

    // Event listeners for form submission
    document.getElementById('billClaimForm').addEventListener('submit', function(e) {
        e.preventDefault();
        if (currentEditIndex >= 0) {
            updateBillClaim();
        } else {
            addBillClaim();
        }
    });

    // Search functionality
    document.getElementById('searchInput').addEventListener('input', function() {
        renderBillClaimsTable();
    });

    // XLSX file upload handler
    document.getElementById('xlsxFile').addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            processBillClaimsXLSX(file);
        }
    });
});

// Process XLSX file
async function processBillClaimsXLSX(file) {
    try {
        const workbook = await readXlsxFile(file);
        const rows = workbook.filter((row, index) => index > 0 && row[0]); // Skip header row

        const newClaims = rows.map(row => ({
            regtNo: String(row[0] || ''),
            name: String(row[1] || ''),
            rank: String(row[2] || ''),
            billType: String(row[3] || ''),
            amount: parseFloat(row[4]) || 0,
            taxable: row[5] === 'Yes' || row[5] === true,
            description: String(row[6] || ''),
            dateAdded: new Date().toISOString()
        }));

        const validClaims = newClaims.filter(claim => 
            claim.regtNo && claim.name && claim.amount > 0
        );

        if (validClaims.length === 0) {
            alert('No valid claims found in the XLSX file');
            return;
        }

        const action = confirm(
            `Found ${validClaims.length} valid claims.\nClick OK to append or Cancel to replace existing claims.`
        );

        billClaims = action ? [...billClaims, ...validClaims] : validClaims;
        saveBillClaims();
        renderBillClaimsTable();
        alert(`Successfully imported ${validClaims.length} claims`);
        document.getElementById('xlsxFile').value = '';
    } catch (error) {
        console.error('Error processing XLSX:', error);
        alert('Error processing XLSX file. Please check the format and try again.');
    }
}

// Load bill claims from localStorage
function loadBillClaims() {
    billClaims = DataManager.loadBillClaims();
}

// Save bill claims to localStorage
function saveBillClaims() {
    DataManager.saveBillClaims(billClaims);
}

// Add a new bill claim
function addBillClaim() {
    const claim = getFormData();
    if (!validateClaimData(claim)) return;

    billClaims.push(claim);
    saveBillClaims();
    clearForm();
    renderBillClaimsTable();
    alert('Bill claim added successfully!');
}

// Get form data
function getFormData() {
    return {
        regtNo: document.getElementById('regtNo').value.trim(),
        name: document.getElementById('name').value.trim(),
        rank: document.getElementById('rank').value.trim(),
        billType: document.getElementById('billType').value,
        amount: parseFloat(document.getElementById('amount').value) || 0,
        taxable: document.getElementById('taxable').checked,
        description: document.getElementById('description').value.trim(),
        dateAdded: new Date().toISOString()
    };
}

// Validate claim data
function validateClaimData(claim) {
    if (!claim.regtNo) {
        alert('Please enter a Regiment Number');
        return false;
    }
    if (!claim.name) {
        alert('Please enter a Name');
        return false;
    }
    if (!claim.billType) {
        alert('Please select a Bill Type');
        return false;
    }
    if (claim.amount <= 0) {
        alert('Please enter a valid amount (greater than 0)');
        return false;
    }
    return true;
}

// Clear the form
function clearForm() {
    document.getElementById('billClaimForm').reset();
    currentEditIndex = -1;
    document.getElementById('submitBtn').textContent = 'Add Claim';
}

// Update an existing bill claim
function updateBillClaim() {
    const claim = getFormData();
    if (!validateClaimData(claim)) return;

    if (currentEditIndex >= 0 && currentEditIndex < billClaims.length) {
        billClaims[currentEditIndex] = claim;
        saveBillClaims();
        renderBillClaimsTable();
        clearForm();
        currentEditIndex = -1;
        document.getElementById('submitBtn').textContent = 'Add Claim';
        alert('Bill claim updated successfully!');
    }
}

// Delete a bill claim
function deleteBillClaim(index) {
    if (confirm('Are you sure you want to delete this bill claim?')) {
        billClaims.splice(index, 1);
        saveBillClaims();
        renderBillClaimsTable();

        if (currentEditIndex === index) {
            clearForm();
            currentEditIndex = -1;
            document.getElementById('submitBtn').textContent = 'Add Claim';
        } else if (currentEditIndex > index) {
            currentEditIndex--;
        }
    }
}

// Edit a bill claim
function editBillClaim(index) {
    if (index >= 0 && index < billClaims.length) {
        currentEditIndex = index;
        const claim = billClaims[index];

        document.getElementById('regtNo').value = claim.regtNo;
        document.getElementById('name').value = claim.name;
        document.getElementById('rank').value = claim.rank;
        document.getElementById('billType').value = claim.billType;
        document.getElementById('amount').value = claim.amount;
        document.getElementById('taxable').checked = claim.taxable;
        document.getElementById('description').value = claim.description;

        document.getElementById('submitBtn').textContent = 'Update Claim';
        document.getElementById('billClaimForm').scrollIntoView({ behavior: 'smooth' });
    }
}

// Render the bill claims table
function renderBillClaimsTable() {
    const tableBody = document.getElementById('billClaimsTableBody');
    const searchText = document.getElementById('searchInput').value.toLowerCase();

    tableBody.innerHTML = '';

    const filteredClaims = billClaims.filter(claim => 
        claim.regtNo.toLowerCase().includes(searchText) ||
        claim.name.toLowerCase().includes(searchText) ||
        claim.billType.toLowerCase().includes(searchText)
    );

    if (filteredClaims.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="7" class="no-data">No bill claims found</td></tr>';
        return;
    }

    filteredClaims.forEach((claim, index) => {
        const originalIndex = billClaims.indexOf(claim);
        const row = document.createElement('tr');

        row.innerHTML = `
            <td>${claim.regtNo}</td>
            <td>${claim.name}</td>
            <td>${claim.rank}</td>
            <td>${claim.billType}</td>
            <td>₹${claim.amount.toLocaleString('en-IN', {maximumFractionDigits: 2})}</td>
            <td>${claim.taxable ? 'Yes' : 'No'}</td>
            <td>
                <button class="btn-edit" onclick="editBillClaim(${originalIndex})">Edit</button>
                <button class="btn-delete" onclick="deleteBillClaim(${originalIndex})">Delete</button>
            </td>
        `;

        tableBody.appendChild(row);
    });

    updateTotalAmount(filteredClaims);
}

// Update the total amount display
function updateTotalAmount(claims) {
    const totalAmount = claims.reduce((sum, claim) => sum + claim.amount, 0);
    const totalTaxable = claims.reduce((sum, claim) => claim.taxable ? sum + claim.amount : sum, 0);

    document.getElementById('totalAmount').textContent = 
        `₹${totalAmount.toLocaleString('en-IN', {maximumFractionDigits: 2})}`;
    document.getElementById('totalTaxable').textContent = 
        `₹${totalTaxable.toLocaleString('en-IN', {maximumFractionDigits: 2})}`;
}

//This function was removed because of XLSX import
// function importFromCSV() {
//     const fileInput = document.getElementById('csvImport');
//     const file = fileInput.files[0];
//
//     if (!file) {
//         alert('Please select a CSV file to import');
//         return;
//     }
//
//     const reader = new FileReader();
//     reader.onload = function(e) {
//         try {
//             const csvData = e.target.result;
//
//             // Parse CSV using PapaParse
//             Papa.parse(csvData, {
//                 header: true,
//                 skipEmptyLines: true,
//                 complete: function(results) {
//                     if (results.data.length === 0) {
//                         alert('No data found in the CSV file');
//                         return;
//                     }
//
//                     // Process and validate the data
//                     const newClaims = results.data.map(row => {
//                         // Convert date string to ISO format
//
//
//                         return {
//                             regtNo: row['Regiment No'] || '',
//                             name: row['Name'] || '',
//                             rank: row['Rank'] || '',
//
//                             billType: row['Bill Type'] || '',
//
//                             amount: parseFloat(row['Amount']) || 0,
//                             taxable: row['Taxable'] === 'Yes',
//                             description: row['Description'] || '',
//                             dateAdded: new Date().toISOString()
//                         };
//                     });
//
//                     // Filter out invalid entries
//                     const validClaims = newClaims.filter(claim =>
//                         claim.regtNo && claim.name && claim.amount > 0
//                     );
//
//                     if (validClaims.length === 0) {
//                         alert('No valid bill claims found in the CSV file');
//                         return;
//                     }
//
//                     // Ask user to append or replace
//                     const action = confirm(
//                         `Found ${validClaims.length} valid bill claims.\n\n` +
//                         'Click OK to append to existing claims, or Cancel to replace all existing claims.'
//                     );
//
//                     if (action) {
//                         // Append
//                         billClaims = [...billClaims, ...validClaims];
//                     } else {
//                         // Replace
//                         billClaims = validClaims;
//                     }
//
//                     saveBillClaims();
//                     renderBillClaimsTable();
//                     alert(`Successfully imported ${validClaims.length} bill claims.`);
//                     fileInput.value = '';
//                 },
//                 error: function(error) {
//                     console.error('Error parsing CSV:', error);
//                     alert('Error parsing CSV file. Please check the format and try again.');
//                 }
//             });
//         } catch (error) {
//             console.error('Error reading CSV file:', error);
//             alert('Error reading CSV file. Please try again.');
//         }
//     };
//
//     reader.onerror = function() {
//         alert('Error reading the file. Please try again.');
//     };
//
//     reader.readAsText(file);
// }
// Export bill claims to CSV
function exportToCSV() {
    if (billClaims.length === 0) {
        alert('No bill claims to export');
        return;
    }

    const headers = ['Regiment No', 'Name', 'Rank', 'Bill Type', 'Amount', 'Taxable', 'Description'];
    let csvContent = headers.join(',') + '\n';

    billClaims.forEach(claim => {
        const formattedDate = claim.billDate ? new Date(claim.billDate).toLocaleDateString() : '';
        const row = [
            `"${claim.regtNo}"`,
            `"${claim.name}"`,
            `"${claim.rank}"`,

            `"${claim.billType}"`,

            claim.amount,
            claim.taxable ? 'Yes' : 'No',
            `"${claim.description.replace(/"/g, '""')}"`
        ];

        csvContent += row.join(',') + '\n';
    });

    // Create and download the CSV file
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'bill_claims.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}