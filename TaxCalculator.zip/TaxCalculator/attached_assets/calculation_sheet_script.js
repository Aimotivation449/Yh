let allData = {};
let currentPage = 0;
let employeeIds = [];
let xlsxDataMap = new Map();
let activeDatePicker = null;
let billClaimsData = [];

const columnMap = {
    regtNo: 0, rank: 2, name: 4, pan: 7, month: 8,
    basicPay: 9, da: 11, tpt: 12, hra: 13,
    dressAll: 14, nurseDressAll: 15, bonus: 16,
    rma: 17, daArrear: 18, familyPay: 19,
    personalPay: 20, soapAll: 21, hindiPay: 22,
    specialPay: 23, hca: 24, hpca: 25, rha: 26,
    sdaCa: 27, rumCigaretteAll: 28, gpf: 30, cpf: 31, cgegis: 32, cghs: 33, gjspkk: 34, tax: 35, hrr: 36, pli: 37, recovery: 39
};

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Try to load data from localStorage
    loadAllData();

    // Initialize any employees already in the data
    if (Object.keys(allData).length > 0) {
        generateOutput();
    }
});

// Load all data from localStorage using DataManager
function loadAllData() {
    try {
        // Load salary data
        allData = DataManager.loadSalaryData();

        // Load bill claims data
        billClaimsData = DataManager.loadBillClaims();
    } catch (error) {
        console.error('Error loading data from localStorage:', error);
        alert('Error loading saved data. Starting with empty dataset.');
        allData = {};
        billClaimsData = [];
    }
}

// Parse number values safely
function safeParseNumber(value) {
    if (typeof value === 'number') return value;
    const cleaned = String(value).replace(/,/g, '').replace(/[^0-9.-]/g, '');
    const parsed = parseFloat(cleaned);
    return isNaN(parsed) ? 0 : parsed;
}

// Process CSV file
function processCSV() {
    const file = document.getElementById('csvFile').files[0];
    if (!file) {
        alert("Please select a CSV file to upload.");
        return;
    }

    Papa.parse(file, {
        complete: (result) => {
            processCSVData(result.data);
            localStorage.setItem('salaryData', JSON.stringify(allData));
            generateOutput();
        },
        error: (error) => {
            console.error('Error parsing CSV:', error);
            alert('Error parsing CSV file. Please check the format and try again.');
        }
    });
}

// Process XLSX file
function processXLSX() {
    const file = document.getElementById('xlsxFile').files[0];
    if (!file) {
        alert("Please select an XLSX file to upload.");
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const xlsxData = XLSX.utils.sheet_to_json(sheet, { header: 1 });
            processXLSXData(xlsxData);
            localStorage.setItem('salaryData', JSON.stringify(allData));
            generateOutput();
        } catch (error) {
            console.error('Error processing XLSX:', error);
            alert('Error processing XLSX file. Please check the format and try again.');
        }
    };
    reader.onerror = () => {
        alert('Error reading the file. Please try again.');
    };
    reader.readAsArrayBuffer(file);
}

// Process CSV data
function processCSVData(data) {
    // Skip header row
    data.slice(1).forEach(row => {
        if (row.length < 40) return;
        const regtNo = String(row[columnMap.regtNo]).trim();
        if (!regtNo) return;

        if (!allData[regtNo]) allData[regtNo] = [];

        const entry = createEntry(row);
        calculateTotal(entry.details);

        // Check if this month already exists for this employee
        const existingIndex = allData[regtNo].findIndex(e => e.month === entry.month);
        if (existingIndex >= 0) {
            // Update existing entry
            allData[regtNo][existingIndex] = entry;
        } else {
            // Add new entry
            allData[regtNo].push(entry);
        }
    });
}

// Create entry object from row data
function createEntry(row) {
    return {
        month: String(row[columnMap.month]).trim(),
        details: {
            rank: String(row[columnMap.rank]).trim(),
            name: String(row[columnMap.name]).trim(),
            pan: String(row[columnMap.pan]).trim(),
            basicPay: safeParseNumber(row[columnMap.basicPay]),
            da: safeParseNumber(row[columnMap.da]),
            tpt: safeParseNumber(row[columnMap.tpt]),
            hra: safeParseNumber(row[columnMap.hra]),
            dressAll: safeParseNumber(row[columnMap.dressAll]),
            nurseDressAll: safeParseNumber(row[columnMap.nurseDressAll]),
            bonus: safeParseNumber(row[columnMap.bonus]),
            rma: safeParseNumber(row[columnMap.rma]),
            daArrear: safeParseNumber(row[columnMap.daArrear]),
            familyPay: safeParseNumber(row[columnMap.familyPay]),
            personalPay: safeParseNumber(row[columnMap.personalPay]),
            soapAll: safeParseNumber(row[columnMap.soapAll]),
            hindiPay: safeParseNumber(row[columnMap.hindiPay]),
            specialPay: safeParseNumber(row[columnMap.specialPay]),
            hca: safeParseNumber(row[columnMap.hca]),
            hpca: safeParseNumber(row[columnMap.hpca]),
            rha: safeParseNumber(row[columnMap.rha]),
            sdaCa: safeParseNumber(row[columnMap.sdaCa]),
            rumCigaretteAll: safeParseNumber(row[columnMap.rumCigaretteAll]),
            xlsxCol4: 0,
            xlsxCol5: 0,
            xlsxCol6: 0,
            total: 0,
            gpf: safeParseNumber(row[columnMap.gpf]),
            cpf: safeParseNumber(row[columnMap.cpf]),
            cgegis: safeParseNumber(row[columnMap.cgegis]), 
            cghs: safeParseNumber(row[columnMap.cghs]),
            gjspkk: safeParseNumber(row[columnMap.gjspkk]),
            tax: safeParseNumber(row[columnMap.tax]),
            hrr: safeParseNumber(row[columnMap.hrr]),
            pli: safeParseNumber(row[columnMap.pli]),
            recovery: safeParseNumber(row[columnMap.recovery])
        }
    };
}

// Process XLSX data
function processXLSXData(data) {
    xlsxDataMap.clear();
    // Skip header row
    data.slice(1).forEach((row, index) => {
        if (!row || row.length < 6) return;
        const regtNo = String(row[0]).trim();
        if (!regtNo) return;

        if (!xlsxDataMap.has(regtNo)) {
            xlsxDataMap.set(regtNo, []);
        }

        xlsxDataMap.get(regtNo).push({
            col4: safeParseNumber(row[3]),
            col5: safeParseNumber(row[4]),
            col6: safeParseNumber(row[5])
        });
    });

    updateAllDataWithXLSX();
}

// Download tax information
function downloadTaxInfo() {
    if (Object.keys(allData).length === 0) {
        alert('No data available. Please upload salary data first.');
        return;
    }

    let csvContent = "Regiment No,Name,Rank,PAN,Annual Income,Standard Deduction,Additional Income,Recoveries,Taxable Income,I-Tax,Marginal Relief,Net Tax,Health & Education Cess,Manual Tax Deductions,Total Tax,Monthly Deduction\n";

    Object.keys(allData).forEach(regtNo => {
        const employee = allData[regtNo];
        if (!employee || employee.length === 0) return;

        const retirementDateInput = document.getElementById(`retirementDate-${employeeIds.indexOf(regtNo)}`);
        const retirementDate = retirementDateInput ? retirementDateInput.value : null;

        // Save retirement date to localStorage
        if (retirementDate) {
            DataManager.saveRetirementDate(regtNo, retirementDate);
        }

        const extendedData = extendTo12Months(employee, retirementDate);
        const monthsCount = extendedData.length;

        // Calculate annual total from extended data
        const annualTotal = extendedData.reduce((sum, entry) => sum + entry.details.total, 0);

        // Get manual bill claims and recoveries for this employee
        const empClaims = billClaimsData.filter(claim => claim.regtNo === regtNo);
        const additionalIncome = empClaims
            .filter(claim => claim.billType !== 'Recovery' && claim.billType !== 'Tax Deduction' && claim.taxable)
            .reduce((sum, claim) => sum + claim.amount, 0);

        const recoveries = empClaims
            .filter(claim => claim.billType === 'Recovery')
            .reduce((sum, claim) => sum + claim.amount, 0);

        const manualTaxDeductions = empClaims
            .filter(claim => claim.billType === 'Tax Deduction')
            .reduce((sum, claim) => sum + claim.amount, 0);

        // Standard deduction
        const standardDeduction = 75000;

        // Calculate taxable income
        const taxableIncome = Math.max(0, Math.round(annualTotal + additionalIncome - recoveries - standardDeduction));

        // Calculate tax
        const tax = calculateTax(taxableIncome);
        const marginalRelief = calculateMarginalRelief(taxableIncome, tax);
        const netTax = tax - marginalRelief;
        const cess = Math.round(netTax * 0.04);
        const grossTax = netTax + cess;
        const totalTax = Math.max(0, grossTax - manualTaxDeductions);

        // Calculate monthly deduction
        const monthlyDeduction = monthsCount > 0 ? Math.round(totalTax / monthsCount) : 0;

        const firstEntry = employee[0].details;

        csvContent += `${regtNo},${firstEntry.name},${firstEntry.rank},${firstEntry.pan},${annualTotal.toFixed(2)},${standardDeduction.toFixed(2)},${additionalIncome.toFixed(2)},${recoveries.toFixed(2)},${taxableIncome.toFixed(2)},${tax.toFixed(2)},${marginalRelief.toFixed(2)},${netTax.toFixed(2)},${cess.toFixed(2)},${manualTaxDeductions.toFixed(2)},${totalTax.toFixed(2)},${monthlyDeduction.toFixed(2)}\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'tax_information.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}

// Calculate marginal relief
function calculateMarginalRelief(income, tax) {
    if (income <= 700000) return 0;

    if (income > 700000 && income <= 750000) {
        // Calculate tax for 700000
        const taxAt700k = calculateTax(700000);

        // Additional income above 700000
        const additionalIncome = income - 700000;

        // Additional tax above 700000
        const additionalTax = tax - taxAt700k;

        // If additional tax is more than additional income, provide relief
        if (additionalTax > additionalIncome) {
            return additionalTax - additionalIncome;
        }
    }

    return 0;
}

// Update all data with XLSX data
function updateAllDataWithXLSX() {
    Object.keys(allData).forEach(regtNo => {
        const xlsxEntries = xlsxDataMap.get(regtNo) || [];
        allData[regtNo].forEach((entry, index) => {
            const xlsxData = xlsxEntries[index] || { col4: 0, col5: 0, col6: 0 };
            entry.details.xlsxCol4 = xlsxData.col4;
            entry.details.xlsxCol5 = xlsxData.col5;
            entry.details.xlsxCol6 = xlsxData.col6;
            calculateTotal(entry.details);
        });
    });
}

// Calculate total for a details object
function calculateTotal(details) {
    const grossValues = [
        details.basicPay, details.da, details.tpt, details.hra,
        details.dressAll, details.nurseDressAll, details.bonus,
        details.rma, details.daArrear, details.familyPay,
        details.personalPay, details.soapAll, details.hindiPay,
        details.specialPay, details.hca, details.hpca, details.rha,
        details.sdaCa, details.rumCigaretteAll,
        details.xlsxCol4, details.xlsxCol5, details.xlsxCol6
    ];

    // Calculate gross total
    details.total = grossValues.reduce((sum, val) => sum + val, 0);
}

// Generate output for all employees
function generateOutput() {
    const results = document.getElementById('results');
    results.innerHTML = '';
    employeeIds = Object.keys(allData);

    if (employeeIds.length === 0) {
        results.innerHTML = '<div class="no-data-message">No data available. Please upload salary data first.</div>';
        document.getElementById('navButtons').style.display = 'none';
        return;
    }

    employeeIds.forEach((regtNo, index) => {
        const employee = allData[regtNo];
        if (!employee || employee.length === 0) return;

        // Check for saved retirement date
        let retirementDate = null;
        try {
            retirementDate = DataManager.getRetirementDate(regtNo);
        } catch (error) {
            console.error(`Error loading retirement date for ${regtNo}:`, error);
        }

        const extendedData = extendTo12Months(employee, retirementDate);

        const page = createEmployeePage(regtNo, index, extendedData, retirementDate);
        results.appendChild(page);

        // Add tax projections to each employee page
        calculateTaxProjections(regtNo, index, extendedData);
    });

    document.getElementById('navButtons').style.display = 'flex';
    showPage(currentPage);
}

// Create an employee page with retirement date picker
function createEmployeePage(regtNo, index, data, savedRetirementDate) {
    const page = document.createElement('div');
    page.className = 'employee-page';
    page.id = `page-${index}`;

    // Date picker container
    const dateContainer = document.createElement('div');
    dateContainer.className = 'date-picker-container';
    dateContainer.innerHTML = `
        <label>Retirement Date: </label>
        <input type="text" id="retirementDate-${index}" class="flatpickr-input" placeholder="Select Date" value="${savedRetirementDate || ''}">
    `;

    const table = createEmployeeTable(regtNo, data);

    // Create a container for retirement notice
    const retirementNotice = document.createElement('div');
    retirementNotice.className = 'retirement-notice';
    retirementNotice.id = `retirement-notice-${index}`;

    // Check if we have a retirement date to display
    if (savedRetirementDate && data[0] && data[0].details) {
        const employeeName = data[0].details.name || 'Employee';
        retirementNotice.innerHTML = `<p>${employeeName} retires as on ${savedRetirementDate}</p>`;

        // Add styling to make it stand out
        retirementNotice.style.backgroundColor = '#fff3cd';
        retirementNotice.style.color = '#856404';
        retirementNotice.style.padding = '10px';
        retirementNotice.style.borderRadius = '5px';
        retirementNotice.style.marginBottom = '15px';
        retirementNotice.style.fontWeight = 'bold';
        retirementNotice.style.textAlign = 'center';
    }

    page.appendChild(dateContainer);
    page.appendChild(retirementNotice);
    page.appendChild(table);

    // Tax section will be added later through calculateTaxProjections

    // Initialize Flatpickr after the element is added to the DOM
    setTimeout(() => {
        const flatpickrInstance = flatpickr(`#retirementDate-${index}`, {
            dateFormat: "Y-m-d",
            altInput: true,
            altFormat: "F j, Y",
            static: true,
            monthSelectorType: 'static',
            onChange: (selectedDates) => {
                if(selectedDates.length > 0) {
                    updateRetirementDate(index, selectedDates[0]);
                    flatpickrInstance.close();
                }
            }
        });
    }, 100);

    return page;
}

// Update based on retirement date
function updateRetirementDate(index, date) {
    const regtNo = employeeIds[index];
    if (!regtNo || !allData[regtNo]) return;

    const employee = allData[regtNo];

    // Format date to string
    const formattedDate = date instanceof Date 
        ? date.toISOString().split('T')[0] 
        : date;

    // Save to localStorage using DataManager
    DataManager.saveRetirementDate(regtNo, formattedDate);

    // Update the UI with new data
    const extendedData = extendTo12Months(employee, formattedDate);

    // Update retirement notice
    const retirementNotice = document.getElementById(`retirement-notice-${index}`);
    if (retirementNotice) {
        const employeeName = employee[0]?.details?.name || 'Employee';
        retirementNotice.innerHTML = `<p>${employeeName} retires as on ${formattedDate}</p>`;

        // Add styling to make it stand out
        retirementNotice.style.backgroundColor = '#fff3cd';
        retirementNotice.style.color = '#856404';
        retirementNotice.style.padding = '10px';
        retirementNotice.style.borderRadius = '5px';
        retirementNotice.style.marginBottom = '15px';
        retirementNotice.style.fontWeight = 'bold';
        retirementNotice.style.textAlign = 'center';
    }

    // Replace the current page with updated data
    const results = document.getElementById('results');
    const oldPage = document.getElementById(`page-${index}`);
    if (oldPage) {
        const newPage = createEmployeePage(regtNo, index, extendedData, formattedDate);
        results.replaceChild(newPage, oldPage);

        // Recalculate tax projections
        calculateTaxProjections(regtNo, index, extendedData);

        showPage(currentPage);
    }
}

// Create employee salary table
function createEmployeeTable(regtNo, data) {
    if (!data || data.length === 0) return document.createElement('div');

    const firstEntry = data[0];
    const details = firstEntry.details;

    const tableContainer = document.createElement('div');
    tableContainer.className = 'employee-table-container';

    // Employee header section
    const header = document.createElement('div');
    header.className = 'employee-header';
    header.innerHTML = `
        <h2>Salary Details - ${details.name} (${regtNo})</h2>
        <p><strong>Rank:</strong> ${details.rank} | <strong>PAN:</strong> ${details.pan || 'N/A'}</p>
    `;
    tableContainer.appendChild(header);

    // Salary table
    const table = document.createElement('table');

    // Table header
    let headerHTML = `
        <tr>
            <th>Component</th>
    `;

    // Add a column for each month
    data.forEach((entry, i) => {
        headerHTML += `<th>${entry.month || `Month ${i+1}`}</th>`;
    });

    headerHTML += `
            <th>Total</th>
        </tr>
    `;

    table.innerHTML = `<thead>${headerHTML}</thead>`;

    // Table body
    const tbody = document.createElement('tbody');

    // Add rows for each component
    const components = [
        { key: 'basicPay', label: 'Basic Pay' },
        { key: 'da', label: 'DA' },
        { key: 'tpt', label: 'TPT' },
        { key: 'hra', label: 'HRA' },
        { key: 'dressAll', label: 'Dress Allowance' },
        { key: 'nurseDressAll', label: 'Nurse Dress Allowance' },
        { key: 'bonus', label: 'Bonus' },
        { key: 'rma', label: 'RMA' },
        { key: 'daArrear', label: 'DA Arrear' },
        { key: 'familyPay', label: 'Family Pay' },
        { key: 'personalPay', label: 'Personal Pay' },
        { key: 'soapAll', label: 'Soap Allowance' },
        { key: 'hindiPay', label: 'Hindi Pay' },
        { key: 'specialPay', label: 'Special Pay' },
        { key: 'hca', label: 'HCA' },
        { key: 'hpca', label: 'HPCA' },
        { key: 'rha', label: 'RHA' },
        { key: 'sdaCa', label: 'SDA/CA' },
        { key: 'rumCigaretteAll', label: 'Rum/Cigarette Allowance' },
        { key: 'xlsxCol4', label: 'Pay Arr-1' },
        { key: 'xlsxCol5', label: 'HRA Arr' },
        { key: 'xlsxCol6', label: 'Other Arr'}
    ];

    // Add rows for each component
    components.forEach(component => {
        const row = document.createElement('tr');
        let rowHTML = `<td>${component.label}</td>`;

        let componentTotal = 0;

        data.forEach(entry => {
            const value = entry.details[component.key] || 0;
            componentTotal += value;
            rowHTML += `<td>₹${value.toLocaleString('en-IN')}</td>`;
        });

        rowHTML += `<td>₹${componentTotal.toLocaleString('en-IN')}</td>`;
        row.innerHTML = rowHTML;
        tbody.appendChild(row);
    });

    // Add total row
    const totalRow = document.createElement('tr');
    totalRow.className = 'total-row';
    let totalRowHTML = `<td><strong>Total</strong></td>`;

    let grandTotal = 0;

    data.forEach(entry => {
        const total = entry.details.total || 0;
        grandTotal += total;
        totalRowHTML += `<td><strong>₹${total.toLocaleString('en-IN')}</strong></td>`;
    });

    totalRowHTML += `<td><strong>₹${grandTotal.toLocaleString('en-IN')}</strong></td>`;
    totalRow.innerHTML = totalRowHTML;
    tbody.appendChild(totalRow);

    // Add deductions section
    const deductionsHeader = document.createElement('tr');
    deductionsHeader.innerHTML = `<td colspan="${data.length + 2}" style="background-color: #e0e0e0; text-align: center;"><strong>Deductions</strong></td>`;
    tbody.appendChild(deductionsHeader);

    // Add deduction components
    const deductions = [
        { key: 'gpf', label: 'GPF' },
        { key: 'cpf', label: 'CPF' },
        { key: 'cgegis', label: 'CGEGIS' },
        { key: 'cghs', label: 'CGHS' },
        { key: 'gjspkk', label: 'GJSPKK' },
        { key: 'tax', label: 'Income Tax' },
        { key: 'hrr', label: 'HRR' },
        { key: 'pli', label: 'PLI' },
        { key: 'recovery', label: 'Recovery' }
    ];

    deductions.forEach(deduction => {
        const row = document.createElement('tr');
        let rowHTML = `<td>${deduction.label}</td>`;

        let deductionTotal = 0;

        data.forEach(entry => {
            const value = entry.details[deduction.key] || 0;
            deductionTotal += value;
            rowHTML += `<td>₹${value.toLocaleString('en-IN')}</td>`;
        });

        rowHTML += `<td>₹${deductionTotal.toLocaleString('en-IN')}</td>`;
        row.innerHTML = rowHTML;
        tbody.appendChild(row);
    });

    table.appendChild(tbody);
    tableContainer.appendChild(table);

    return tableContainer;
}

// Calculate tax projections for an employee
function calculateTaxProjections(regtNo, index, extendedData) {
    if (!regtNo || !extendedData || extendedData.length === 0) return;

    const page = document.getElementById(`page-${index}`);
    if (!page) return;

    // Calculate annual total
    const annualTotal = extendedData.reduce((sum, entry) => sum + entry.details.total, 0);

    // Get CSV file recoveries
    const csvRecoveries = extendedData.reduce((sum, entry) => {
        return sum + (entry.details.recovery || 0);
    }, 0);

    // Get CSV file tax deductions
    const csvTaxDeductions = extendedData.reduce((sum, entry) => {
        return sum + (entry.details.tax || 0);
    }, 0);

    // Get manual bill claims and recoveries for this employee
    const empClaims = billClaimsData.filter(claim => claim.regtNo === regtNo);
    const additionalIncome = empClaims
        .filter(claim => claim.billType !== 'Recovery' && claim.billType !== 'Tax Deduction' && claim.taxable)
        .reduce((sum, claim) => sum + (parseFloat(claim.amount) || 0), 0);

    const manualRecoveries = empClaims
        .filter(claim => claim.billType === 'Recovery')
        .reduce((sum, claim) => sum + (parseFloat(claim.amount) || 0), 0);

    const manualTaxDeductions = empClaims
        .filter(claim => claim.billType === 'Tax Deduction')
        .reduce((sum, claim) => sum + (parseFloat(claim.amount) || 0), 0);

    // Total recoveries (manual + CSV)
    const totalRecoveries = csvRecoveries + manualRecoveries;

    // Total tax deductions (manual + CSV)
    const totalTaxDeductions = csvTaxDeductions + manualTaxDeductions;

    // Standard deduction
    const standardDeduction = 75000;

    // Calculate taxable income
    const taxableIncome = Math.max(0, Math.round(annualTotal + additionalIncome - totalRecoveries - standardDeduction));

    // Calculate tax
    const tax = calculateTax(taxableIncome);
    const marginalRelief = calculateMarginalRelief(taxableIncome, tax);
    const netTax = tax - marginalRelief;
    const cess = Math.round(netTax * 0.04);
    const grossTax = netTax + cess;
    const totalTax = Math.max(0, grossTax - totalTaxDeductions);

    // Calculate monthly deduction
    const monthlyDeduction = extendedData.length > 0 ? Math.round(totalTax / extendedData.length) : 0;

    // Create tax section
    const existingTaxSection = page.querySelector('.tax-section');
    if (existingTaxSection) {
        existingTaxSection.remove();
    }

    const taxSection = document.createElement('div');
    taxSection.className = 'tax-section';

    let taxHTML = `
        <h3>Tax Projection</h3>
        <table>
            <tr>
                <th>Component</th>
                <th>Amount</th>
            </tr>
            <tr>
                <td>Gross Annual Salary</td>
                <td>₹${annualTotal.toLocaleString('en-IN')}</td>
            </tr>
            <tr>
                <td>Additional Income (Manual Claims)</td>
                <td>₹${additionalIncome.toLocaleString('en-IN')}</td>
            </tr>
            <tr>
                <td>CSV File Recoveries</td>
                <td>₹${csvRecoveries.toLocaleString('en-IN')}</td>
            </tr>
            <tr>
                <td>Manual Recoveries</td>
                <td>₹${manualRecoveries.toLocaleString('en-IN')}</td>
            </tr>
            <tr>
                <td>Total Recoveries</td>
                <td>₹${totalRecoveries.toLocaleString('en-IN')}</td>
            </tr>
            <tr>
                <td>Standard Deduction</td>
                <td>₹${standardDeduction.toLocaleString('en-IN')}</td>
            </tr>
            <tr class="total-row">
                <td>Taxable Income</td>
                <td>₹${taxableIncome.toLocaleString('en-IN')}</td>
            </tr>
            <tr>
                <td>Income Tax</td>
                <td>₹${tax.toLocaleString('en-IN')}</td>
            </tr>
    `;

    // Add marginal relief section if applicable
    if (marginalRelief > 0) {
        taxHTML += `
            <tr>
                <td>Marginal Relief</td>
                <td>₹${marginalRelief.toLocaleString('en-IN')}</td>
            </tr>
            <tr>
                <td>Net Tax</td>
                <td>₹${netTax.toLocaleString('en-IN')}</td>
            </tr>
        `;
    }

    taxHTML += `
            <tr>
                <td>Health & Education Cess (4%)</td>
                <td>₹${cess.toLocaleString('en-IN')}</td>
            </tr>
            <tr>
                <td>Gross Tax</td>
                <td>₹${grossTax.toLocaleString('en-IN')}</td>
            </tr>
    `;

    // Add tax deductions
    taxHTML += `
        <tr>
            <td>CSV File Tax Deductions (I-Tax)</td>
            <td>₹${csvTaxDeductions.toLocaleString('en-IN')}</td>
        </tr>
    `;

    // Add manual tax deductions if applicable
    if (manualTaxDeductions > 0) {
        taxHTML += `
            <tr>
                <td>Manual Tax Deductions</td>
                <td>₹${manualTaxDeductions.toLocaleString('en-IN')}</td>
            </tr>
        `;
    }

    // Add total tax deductions if both types exist
    if (csvTaxDeductions > 0 && manualTaxDeductions > 0) {
        taxHTML += `
            <tr>
                <td>Total Tax Deductions</td>
                <td>₹${totalTaxDeductions.toLocaleString('en-IN')}</td>
            </tr>
        `;
    }

    taxHTML += `
            <tr class="total-row">
                <td>Total Tax</td>
                <td>₹${totalTax.toLocaleString('en-IN')}</td>
            </tr>
            <tr>
                <td>Monthly Deduction (${extendedData.length} months)</td>
                <td>₹${monthlyDeduction.toLocaleString('en-IN')}</td>
            </tr>
        </table>
    `;

    // Add marginal relief box if applicable
    if (marginalRelief > 0) {
        taxHTML += `
            <div class="relief-box">
                <h4>Marginal Relief Applied</h4>
                <p>Since your income is just above ₹12,00,000, marginal relief of ₹${marginalRelief.toLocaleString('en-IN')} has been applied to ensure the additional tax paid does not exceed the additional income earned.</p>
            </div>
        `;
    }

    // Add 87A rebate information if applicable
    if (taxableIncome <= 1200000 && tax > 0) {
        taxHTML += `
            <div class="relief-box">
                <h4>Section 87A Rebate Applied</h4>
                <p>Since your taxable income is up to ₹12,00,000, a rebate of up to ₹60,000 under Section 87A has been applied to reduce your tax liability.</p>
            </div>
        `;
    }

    taxSection.innerHTML = taxHTML;
    page.appendChild(taxSection);
}

// Navigation functions
function searchEmployees() {
    const searchTerm = document.getElementById('employeeSearch').value.toLowerCase().trim();
    
    // Store original IDs if not already stored
    if (!window.originalEmployeeIds) {
        window.originalEmployeeIds = [...employeeIds];
    }
    
    if (searchTerm === '') {
        employeeIds = [...window.originalEmployeeIds];
        currentPage = 0;
        generateOutput();
        return;
    }
    
    // Use original IDs for searching
    const filteredIds = window.originalEmployeeIds.filter(id => {
        const employee = allData[id]?.[0]?.details;
        if (!employee) return false;
        
        const regtNo = id.toLowerCase();
        const name = (employee.name || '').toLowerCase();
        
        return regtNo.includes(searchTerm) || name.includes(searchTerm);
    });
    
    // Update display based on search results
    if (filteredIds.length > 0) {
        employeeIds = filteredIds;
        currentPage = 0;
        
        const results = document.getElementById('results');
        results.innerHTML = ''; // Clear current results
        
        // Regenerate the output with filtered results
        generateOutput();
    } else if (searchTerm === '') {
        // If search is cleared, restore original list
        employeeIds = [...window.originalEmployeeIds];
        currentPage = 0;
        generateOutput();
    } else {
        alert('No matching employees found');
        // Keep the current display
    }
}

// Add event listener for search input
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('employeeSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            if (e.target.value === '') {
                // Clear search
                if (window.originalEmployeeIds) {
                    employeeIds = [...window.originalEmployeeIds];
                    currentPage = 0;
                    generateOutput();
                }
            }
        });
    }
});

function showPage(index) {
    if (employeeIds.length === 0) return;

    // Ensure index is valid
    if (index < 0) index = 0;
    if (index >= employeeIds.length) index = employeeIds.length - 1;

    currentPage = index;

    // Hide all pages
    const pages = document.querySelectorAll('.employee-page');
    pages.forEach(page => page.classList.remove('active'));

    // Show current page
    const currentPageElement = document.getElementById(`page-${index}`);
    if (currentPageElement) {
        currentPageElement.classList.add('active');
    }
}

function showNextPage() {
    showPage(currentPage + 1);
}

function showPreviousPage() {
    showPage(currentPage - 1);
}

// Process recovery XLSX file
function processRecoveryXLSX() {
    const file = document.getElementById('xlsxFile').files[0];
    if (!file) {
        alert("Please select an XLSX file to upload.");
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const recoveryData = XLSX.utils.sheet_to_json(sheet, { header: 1 });
            
            // Skip header row and process data
            recoveryData.slice(1).forEach(row => {
                if (!row || row.length < 3) return;
                
                const recovery = {
                    regtNo: String(row[0]).trim(),
                    type: String(row[1]).trim(),
                    amount: parseFloat(row[2]) || 0,
                    description: String(row[3] || '').trim()
                };
                
                // Save recovery to local storage
                const existingClaims = DataManager.loadBillClaims() || [];
                existingClaims.push({
                    regtNo: recovery.regtNo,
                    billType: 'Recovery',
                    description: recovery.description,
                    amount: recovery.amount,
                    date: recovery.startDate,
                    endDate: recovery.endDate,
                    installments: recovery.installments
                });
                
                DataManager.saveBillClaims(existingClaims);
            });
            
            alert('Recovery data uploaded successfully!');
            generateOutput(); // Refresh the display
            
        } catch (error) {
            console.error('Error processing XLSX:', error);
            alert('Error processing XLSX file. Please check the format and try again.');
        }
    };
    reader.onerror = () => {
        alert('Error reading the file. Please try again.');
    };
    reader.readAsArrayBuffer(file);
}

function calculateTax(income) {
    const slabs = [
        { limit: 300000, rate: 0 },
        { limit: 600000, rate: 0.05 },
        { limit: 900000, rate: 0.10 },
        { limit: 1200000, rate: 0.15 },
        { limit: 1500000, rate: 0.20 },
        { limit: 1800000, rate: 0.25 },
        { limit: Infinity, rate: 0.30 }
    ];

    let tax = 0;
    let remainingIncome = income;

    for (const slab of slabs) {
        const taxableAmount = Math.min(remainingIncome, slab.limit - (slabs[slabs.indexOf(slab) -1]?.limit || 0));
        tax += taxableAmount * slab.rate;
        remainingIncome -= taxableAmount;
        if (remainingIncome <= 0) break;
    }

    return tax;
}

function extendTo12Months(employeeData, retirementDate) {
    if (!employeeData || employeeData.length === 0) return [];

    const months = [
        "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep",
        "Oct", "Nov", "Dec", "Jan", "Feb"
    ];

    const extendedData = [];
    const lastEntry = employeeData[employeeData.length - 1];
    const baseDetails = lastEntry.details;
    const fiscalYear = new Date().getFullYear(); // Assuming fiscal year starts in April

    // Find the current month index in our fiscal year array
    let currentMonthIndex = months.findIndex(m => 
        lastEntry.month.toLowerCase().startsWith(m.toLowerCase())
    );

    if (currentMonthIndex === -1) {
        currentMonthIndex = new Date().getMonth() - 3; // Adjust for fiscal year (April = 0)
        if (currentMonthIndex < 0) currentMonthIndex += 12;
    }

    // Add existing data first
    employeeData.forEach(entry => extendedData.push(JSON.parse(JSON.stringify(entry))));

    // Extend remaining months
    while (extendedData.length < 12) {
        currentMonthIndex = (currentMonthIndex + 1) % 12;
        // Determine year suffix for the month
        const isNextYear = currentMonthIndex >= 9; // Jan and Feb are next year
        const yearToUse = isNextYear ? fiscalYear + 1 : fiscalYear;
        const yearSuffix = yearToUse.toString().slice(-2);

        const nextMonth = {
            month: `${months[currentMonthIndex]}-${yearSuffix}`,
            details: {
                ...JSON.parse(JSON.stringify(baseDetails)),
                bonus: 0,
                daArrear: 0
            }
        };

        // If retirement date is set and we've passed it, zero out all values
        if (retirementDate) {
            const retDate = new Date(retirementDate);
            const currentDate = new Date(yearToUse, currentMonthIndex + 3, 1); // Adjust for fiscal year
            if (currentDate > retDate) {
                Object.keys(nextMonth.details).forEach(key => {
                    if (typeof nextMonth.details[key] === 'number') {
                        nextMonth.details[key] = 0;
                    }
                });
            }
        }

        extendedData.push(nextMonth);
    }

    return extendedData;
}