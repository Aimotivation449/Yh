function addRecovery() {
    const recovery = {
        regtNo: document.getElementById('regtNo').value,
        type: document.getElementById('recoveryType').value,
        amount: parseFloat(document.getElementById('amount').value),
        description: document.getElementById('description').value
    };

    // Add code here to handle the recovery object (e.g., send it to the server)

}

// Add other necessary functions here.  For example, a function to display recoveries or handle server responses.

// Example of a function to display recoveries (assuming you have an array called 'recoveries')
function displayRecoveries(recoveries) {
    const recoveryList = document.getElementById('recoveryList');
    recoveryList.innerHTML = ''; // Clear existing list

    recoveries.forEach(recovery => {
        const listItem = document.createElement('li');
        listItem.textContent = `Regn No: ${recovery.regtNo}, Type: ${recovery.type}, Amount: ${recovery.amount}, Description: ${recovery.description}`;
        recoveryList.appendChild(listItem);
    });
}


//Example of handling server response (replace with your actual server interaction)
function sendRecoveryToServer(recovery){
    fetch('/api/recoveries', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(recovery)
    })
    .then(response => response.json())
    .then(data => {
        if(data.success){
            //Update UI or display success message
            console.log("Recovery added successfully");
            //Assuming you have an array to store recoveries
            recoveries.push(recovery);
            displayRecoveries(recoveries);
        } else {
            //Handle error
            console.error("Error adding recovery:", data.error);
        }
    })
    .catch(error => {
        console.error("Error:", error);
    })
}


// Example usage (call sendRecoveryToServer after addRecovery)
//let recoveries = []; //Initialize an empty array to store recoveries

//addRecovery();
//sendRecoveryToServer(recovery);