
document.addEventListener('DOMContentLoaded', function() {
    loadTaxDeductions();
    
    document.getElementById('taxForm').addEventListener('submit', function(e) {
        e.preventDefault();
        addTaxDeduction();
    });
    
    document.getElementById('searchInput').addEventListener('input', function() {
        loadTaxDeductions();
    });
});

function addTaxDeduction() {
    const taxDeduction = {
        regtNo: document.getElementById('regtNo').value,
        month: document.getElementById('taxMonth').value,
        amount: parseFloat(document.getElementById('amount').value),
        employerName: document.getElementById('employerName').value || '',
        date: new Date().toISOString().split('T')[0]
    };

    let taxDeductions = [];
    try {
        taxDeductions = JSON.parse(localStorage.getItem('taxDeductions') || '[]');
    } catch (e) {
        console.error('Error loading tax deductions:', e);
    }

    taxDeductions.push(taxDeduction);
    localStorage.setItem('taxDeductions', JSON.stringify(taxDeductions));

    clearForm();
    loadTaxDeductions();
    alert('Tax deduction added successfully!');
}

function loadTaxDeductions() {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    let taxDeductions = [];
    
    try {
        taxDeductions = JSON.parse(localStorage.getItem('taxDeductions') || '[]');
    } catch (e) {
        console.error('Error loading tax deductions:', e);
    }

    const filteredDeductions = searchInput ? 
        taxDeductions.filter(d => d.regtNo.toLowerCase().includes(searchInput)) : 
        taxDeductions;

    const listContainer = document.getElementById('taxDeductionsList');
    
    if (filteredDeductions.length === 0) {
        listContainer.innerHTML = '<p>No tax deductions found.</p>';
        return;
    }

    let html = `
        <table>
            <thead>
                <tr>
                    <th>Regt. No.</th>
                    <th>Month</th>
                    <th>Amount</th>
                    <th>Other Employer</th>
                    <th>Date Added</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
    `;

    filteredDeductions.forEach((deduction, index) => {
        html += `
            <tr>
                <td>${deduction.regtNo}</td>
                <td>${deduction.month}</td>
                <td>₹${deduction.amount.toLocaleString('en-IN')}</td>
                <td>${deduction.employerName || '-'}</td>
                <td>${new Date(deduction.date).toLocaleDateString()}</td>
                <td>
                    <button class="btn-danger" onclick="deleteTaxDeduction(${index})">Delete</button>
                </td>
            </tr>
        `;
    });

    html += '</tbody></table>';
    listContainer.innerHTML = html;
}

function deleteTaxDeduction(index) {
    if (!confirm('Are you sure you want to delete this tax deduction?')) return;

    let taxDeductions = [];
    try {
        taxDeductions = JSON.parse(localStorage.getItem('taxDeductions') || '[]');
        taxDeductions.splice(index, 1);
        localStorage.setItem('taxDeductions', JSON.stringify(taxDeductions));
        loadTaxDeductions();
    } catch (e) {
        console.error('Error deleting tax deduction:', e);
        alert('Error deleting tax deduction. Please try again.');
    }
}

function clearForm() {
    document.getElementById('taxForm').reset();
}

function processTaxXLSX() {
    const file = document.getElementById('taxFile').files[0];
    if (!file) {
        alert("Please select an XLSX file to upload.");
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const taxData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

            // Skip header row and process data
            let taxDeductions = JSON.parse(localStorage.getItem('taxDeductions') || '[]');

            taxData.slice(1).forEach(row => {
                if (!row || row.length < 3) return;

                taxDeductions.push({
                    regtNo: String(row[0]).trim(),
                    month: String(row[1]).trim(),
                    amount: parseFloat(row[2]) || 0,
                    employerName: '',
                    date: new Date().toISOString().split('T')[0]
                });
            });

            localStorage.setItem('taxDeductions', JSON.stringify(taxDeductions));
            loadTaxDeductions();
            alert('Tax deductions uploaded successfully!');
        } catch (error) {
            console.error('Error processing XLSX:', error);
            alert('Error processing XLSX file. Please check the format and try again.');
        }
    };
    reader.readAsArrayBuffer(file);
}

function exportToExcel() {
    let taxDeductions = [];
    try {
        taxDeductions = JSON.parse(localStorage.getItem('taxDeductions') || '[]');
    } catch (e) {
        console.error('Error loading tax deductions for export:', e);
        alert('Error exporting tax deductions. Please try again.');
        return;
    }

    const rows = taxDeductions.map(d => ({
        'Regiment No': d.regtNo,
        'Month': d.month,
        'Amount': d.amount,
        'Other Employer': d.employerName,
        'Date Added': d.date
    }));

    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Tax Deductions');
    XLSX.writeFile(workbook, 'Tax_Deductions_Report.xlsx');
}

function printDeductions() {
    window.print();
}
