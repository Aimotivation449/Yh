/**
 * Data Manager - Handles data persistence for the Income Tax Calculator
 * Provides a centralized approach to storing and retrieving application data
 */
const DataManager = {
    /**
     * Save data to local storage
     * @param {string} key - Storage key
     * @param {any} data - Data to store
     * @returns {boolean} - Success status
     */
    saveData: function(key, data) {
        try {
            localStorage.setItem(key, JSON.stringify(data));
            return true;
        } catch (error) {
            console.error('Error saving data:', error);
            return false;
        }
    },

    /**
     * Load data from local storage
     * @param {string} key - Storage key
     * @param {any} defaultValue - Default value if not found
     * @returns {any} - Retrieved data or default value
     */
    loadData: function(key, defaultValue = null) {
        try {
            const data = localStorage.getItem(key);
            return data ? JSON.parse(data) : defaultValue;
        } catch (error) {
            console.error('Error loading data:', error);
            return defaultValue;
        }
    },

    /**
     * Delete data from local storage
     * @param {string} key - Storage key
     */
    deleteData: function(key) {
        try {
            localStorage.removeItem(key);
        } catch (error) {
            console.error('Error deleting data:', error);
        }
    },

    /**
     * Check if data exists in local storage
     * @param {string} key - Storage key
     * @returns {boolean} - True if data exists
     */
    hasData: function(key) {
        return localStorage.getItem(key) !== null;
    },

    /**
     * Clear all application data
     */
    clearAllData: function() {
        try {
            // Clear specific application data
            const keysToKeep = []; // Add keys to preserve if needed
            
            // Get all keys
            const keys = Object.keys(localStorage);
            
            // Remove keys that are part of this application
            keys.forEach(key => {
                if (!keysToKeep.includes(key)) {
                    localStorage.removeItem(key);
                }
            });
            
            return true;
        } catch (error) {
            console.error('Error clearing data:', error);
            return false;
        }
    },

    /**
     * Save bill claims
     * @param {Array} claims - Bill claims data
     */
    saveBillClaims: function(claims) {
        return this.saveData('billClaims', claims);
    },

    /**
     * Load bill claims
     * @returns {Array} - Bill claims data
     */
    loadBillClaims: function() {
        return this.loadData('billClaims', []);
    },

    /**
     * Save salary data
     * @param {Object} data - Salary data
     */
    saveSalaryData: function(data) {
        return this.saveData('salaryData', data);
    },

    /**
     * Load salary data
     * @returns {Object} - Salary data
     */
    loadSalaryData: function() {
        return this.loadData('salaryData', {});
    },

    /**
     * Load employee data
     * @returns {Array} - Employee data array
     */
    loadEmployeeData: function() {
        return this.loadData('salaryData', []).employees || [];
    },

    /**
     * Save employee configuration (like retirement dates)
     * @param {Object} config - Employee configuration
     */
    saveEmployeeConfig: function(config) {
        return this.saveData('employeeConfig', config);
    },

    /**
     * Load employee configuration
     * @returns {Object} - Employee configuration
     */
    loadEmployeeConfig: function() {
        return this.loadData('employeeConfig', {});
    },

    /**
     * Save retirement date for an employee
     * @param {string} regtNo - Regiment number
     * @param {string} date - Retirement date
     */
    saveRetirementDate: function(regtNo, date) {
        try {
            localStorage.setItem(`retirement_${regtNo}`, date);
            return true;
        } catch (error) {
            console.error('Error saving retirement date:', error);
            return false;
        }
    },

    /**
     * Get retirement date for an employee
     * @param {string} regtNo - Regiment number
     * @returns {string|null} - Retirement date or null
     */
    getRetirementDate: function(regtNo) {
        try {
            return localStorage.getItem(`retirement_${regtNo}`);
        } catch (error) {
            console.error('Error getting retirement date:', error);
            return null;
        }
    },

    /**
     * Export all data to a JSON file
     */
    exportAllData: function() {
        try {
            const data = {
                salaryData: this.loadSalaryData(),
                billClaims: this.loadBillClaims(),
                retirementDates: {}
            };
            
            // Extract retirement dates
            Object.keys(localStorage).forEach(key => {
                if (key.startsWith('retirement_')) {
                    const regtNo = key.replace('retirement_', '');
                    data.retirementDates[regtNo] = localStorage.getItem(key);
                }
            });
            
            // Create and download JSON file
            const jsonString = JSON.stringify(data, null, 2);
            const blob = new Blob([jsonString], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = 'income_tax_calculator_data.json';
            a.click();
            
            URL.revokeObjectURL(url);
            return true;
        } catch (error) {
            console.error('Error exporting data:', error);
            return false;
        }
    },

    /**
     * Import data from a JSON file
     * @param {File} file - JSON file
     * @returns {Promise<boolean>} - Success status
     */
    importData: function(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (event) => {
                try {
                    const data = JSON.parse(event.target.result);
                    
                    // Import salary data
                    if (data.salaryData) {
                        this.saveSalaryData(data.salaryData);
                    }
                    
                    // Import bill claims
                    if (data.billClaims) {
                        this.saveBillClaims(data.billClaims);
                    }
                    
                    // Import retirement dates
                    if (data.retirementDates) {
                        Object.keys(data.retirementDates).forEach(regtNo => {
                            this.saveRetirementDate(regtNo, data.retirementDates[regtNo]);
                        });
                    }
                    
                    resolve(true);
                } catch (error) {
                    console.error('Error importing data:', error);
                    reject(error);
                }
            };
            
            reader.onerror = (error) => {
                reject(error);
            };
            
            reader.readAsText(file);
        });
    }
};