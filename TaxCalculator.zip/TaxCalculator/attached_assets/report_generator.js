/**
 * Report Generator - Handles report generation for the Income Tax Calculator
 * Consolidates data from various sources to create comprehensive reports
 */

const ReportGenerator = {
    /**
     * Generate a comprehensive tax report for all employees
     * @param {Object} salaryData - Employee salary data
     * @param {Array} billClaims - Manual bill claims
     * @returns {Array} - Array of employee tax reports
     */
    generateTaxReport: function(salaryData, billClaims) {
        const taxReports = [];
        const employeeConfig = DataManager.loadEmployeeConfig();
        
        // Process each employee
        Object.keys(salaryData).forEach(regtNo => {
            const employee = salaryData[regtNo];
            if (!employee || !employee.length) return;
            
            // Get employee details from first entry
            const details = employee[0].details;
            
            // Get retirement date if available
            const retirementDate = employeeConfig.retirementDates?.[regtNo] || null;
            
            // Extend data to 12 months respecting retirement date
            const extendedData = this.extendTo12Months(employee, retirementDate);
            
            // Calculate annual salary
            const annualTotal = this.calculateAnnualSalary(extendedData);
            
            // Get manual claims for this employee
            const employeeClaims = billClaims.filter(claim => claim.regtNo === regtNo);
            
            // Calculate total claims amount
            const claimsAmount = this.calculateClaimsAmount(employeeClaims);
            
            // Calculate total recovery amount
            const recoveryAmount = this.calculateRecoveryAmount(employeeClaims);
            
            // Calculate gross income (salary + claims - recovery)
            const grossIncome = annualSalary.grossTotal + claimsAmount;
            
            // Apply standard deduction
            const standardDeduction = 75000;
            const taxableIncome = Math.max(0, grossIncome - standardDeduction);
            
            // Calculate tax on the taxable income
            const taxDetails = this.calculateTax(taxableIncome);
            
            // Subtract any manual tax deductions or I-Tax deductions from monthly salary
            const taxDeductions = this.calculateTaxDeductions(extendedData, employeeClaims);
            taxDetails.netTax = Math.max(0, taxDetails.netTax - taxDeductions);
            taxDetails.grossTax = Math.max(0, taxDetails.grossTax - taxDeductions);
            
            // Create the tax report entry
            taxReports.push({
                regtNo: regtNo,
                name: details.name,
                rank: details.rank,
                pan: details.pan || 'N/A',
                retirementDate: retirementDate,
                grossSalary: annualSalary.grossTotal,
                manualClaims: claimsAmount,
                manualRecovery: recoveryAmount,
                grossIncome: grossIncome,
                standardDeduction: standardDeduction,
                taxableIncome: taxableIncome,
                taxDetails: taxDetails,
                taxDeductions: taxDeductions,
                monthlyBreakdown: extendedData.map((entry, index) => {
                    return {
                        month: entry.month || `Month ${index + 1}`,
                        grossSalary: entry.details.total,
                        taxDeducted: entry.details.tax || 0
                    };
                })
            });
        });
        
        return taxReports;
    },
    
    /**
     * Calculate annual salary from extended data
     * @param {Array} extendedData - Extended salary data for 12 months
     * @returns {Object} - Annual salary totals
     */
    calculateAnnualSalary: function(extendedData) {
        let grossTotal = 0;
        let deductions = 0;
        
        extendedData.forEach(entry => {
            const details = entry.details;
            grossTotal += details.total || 0;
            
            // Sum up deductions
            const deductionFields = ['0'];
            deductionFields.forEach(field => {
                if (details[field]) {
                    deductions += details[field] || 0;
                }
            });
        });
        
        return { grossTotal, deductions, netTotal: grossTotal - deductions };
    },
    
    /**
     * Calculate total amount from claims that should be added to gross income
     * @param {Array} claims - Employee claims
     * @returns {number} - Total taxable claims amount
     */
    calculateClaimsAmount: function(claims) {
        return claims.reduce((total, claim) => {
            // Only add taxable claims to the gross income
            if (claim.taxable) {
                return total + (parseFloat(claim.amount) || 0);
            }
            return total;
        }, 0);
    },
    
    /**
     * Calculate total recovery amount that should be subtracted from gross income
     * @param {Array} claims - Employee claims (filtering for recovery items)
     * @returns {number} - Total recovery amount
     */
    calculateRecoveryAmount: function(claims) {
        return claims.reduce((total, claim) => {
            // Look for recovery bill types
            if (claim.billType === 'Recovery' || claim.billType === 'Deduction') {
                return total + (parseFloat(claim.amount) || 0);
            }
            return total;
        }, 0);
    },
    
    /**
     * Calculate total tax deductions from salary data and claims
     * @param {Array} extendedData - Extended salary data
     * @param {Array} claims - Employee claims
     * @returns {number} - Total tax deductions
     */
    calculateTaxDeductions: function(extendedData, claims) {
        let totalDeductions = 0;
        
        // Add up tax from salary data (I-Tax column)
        extendedData.forEach(entry => {
            if (entry.details && entry.details.tax) {
                totalDeductions += entry.details.tax || 0;
            }
        });
        
        // Add any manual tax deductions from claims
        claims.forEach(claim => {
            if (claim.billType === 'Tax Deduction' || claim.billType === 'TDS') {
                totalDeductions += parseFloat(claim.amount) || 0;
            }
        });
        
        return totalDeductions;
    },
    
    /**
     * Calculate tax based on the new tax regime
     * @param {number} income - Taxable income
     * @returns {Object} - Tax calculation details
     */
    calculateTax: function(income) {
        const slabs = [
            { limit: 300000, rate: 0 },     // 0-3 lakh: 0%
            { limit: 300000, rate: 0.05 },  // 3-6 lakh: 5%
            { limit: 300000, rate: 0.10 },  // 6-9 lakh: 10%
            { limit: 300000, rate: 0.15 },  // 9-12 lakh: 15%
            { limit: 300000, rate: 0.20 },  // 12-15 lakh: 20%
            { limit: 300000, rate: 0.25 },  // 15-18 lakh: 25%
            { limit: Infinity, rate: 0.30 } // Above 18 lakh: 30%
        ];

        let tax = 0;
        let remainingIncome = income;
        let slabwiseTax = [];

        for (const slab of slabs) {
            if (remainingIncome <= 0) break;
            
            const taxableInThisSlab = Math.min(remainingIncome, slab.limit);
            const taxForThisSlab = taxableInThisSlab * slab.rate;
            
            tax += taxForThisSlab;
            remainingIncome -= slab.limit;
            
            slabwiseTax.push({
                slab: slab.limit,
                rate: slab.rate,
                taxable: taxableInThisSlab,
                tax: taxForThisSlab
            });
        }

        // Apply rebate under section 87A - 60000 for income up to 1200000 (12 Lakh)
        const rebate = income <= 1200000 ? Math.min(tax, 60000) : 0;
        
        // Calculate health and education cess (4% of tax after rebate)
        const taxAfterRebate = Math.max(0, tax - rebate);
        const cess = taxAfterRebate * 0.04;
        
        // Calculate marginal relief if applicable
        const marginalRelief = this.calculateMarginalRelief(income, tax);
        
        return {
            totalIncome: income,
            taxBeforeRebate: tax,
            rebate: rebate,
            taxAfterRebate: taxAfterRebate,
            cess: cess,
            marginalRelief: marginalRelief,
            netTax: Math.max(0, taxAfterRebate + cess - marginalRelief),
            grossTax: Math.max(0, taxAfterRebate + cess),
            slabwiseTax: slabwiseTax,
            monthlyDeduction: Math.ceil((taxAfterRebate + cess - marginalRelief) / 12)
        };
    },
    
    /**
     * Calculate marginal relief for incomes just above tax exemption limit
     * @param {number} income - Taxable income
     * @param {number} tax - Calculated tax
     * @returns {number} - Marginal relief amount
     */
    calculateMarginalRelief: function(income, tax) {
        // Marginal relief is provided for incomes just above Rs. 7 lakhs
        const exemptionLimit = 1200000;
        const threshold = 750000;
        
        if (income > exemptionLimit && income <= threshold) {
            // Calculate the additional income over exemption limit
            const additionalIncome = income - exemptionLimit;
            
            // Marginal relief is the amount by which tax exceeds additional income
            const relief = Math.max(0, tax - additionalIncome);
            
            return relief;
        }
        
        return 0;
    },
    
    /**
     * Extend salary data to 12 months respecting retirement date
     * @param {Array} employeeData - Original employee data
     * @param {string|Date} retirementDate - Retirement date
     * @returns {Array} - Extended data array
     */
    extendTo12Months: function(employeeData, retirementDate) {
        if (!employeeData || !employeeData.length) {
            return [];
        }

        // Make a deep copy of the employee data to avoid modifying the original
        const data = JSON.parse(JSON.stringify(employeeData));
        
        // Determine the months to include based on retirement date
        let monthsToInclude = 12;
        
        if (retirementDate) {
            // Convert string date to Date object if needed
            let retDate = retirementDate;
            if (typeof retirementDate === 'string') {
                retDate = new Date(retirementDate);
            }
            
            if (retDate instanceof Date && !isNaN(retDate.getTime())) {
                // Get the current year
                const currentYear = new Date().getFullYear();
                
                // Calculate months between now and retirement
                const currentMonth = new Date().getMonth();
                const retirementMonth = retDate.getMonth();
                const retirementYear = retDate.getFullYear();
                
                // If retirement is this year, calculate remaining months
                if (retirementYear === currentYear) {
                    monthsToInclude = Math.max(0, retirementMonth - currentMonth + 1);
                } 
                // If retirement is next year, include all months until retirement
                else if (retirementYear === currentYear + 1) {
                    monthsToInclude = (12 - currentMonth) + retirementMonth + 1;
                }
                
                // Cap at 12 months
                monthsToInclude = Math.min(12, Math.max(0, monthsToInclude));
            }
        }
        
        // If we have no months to include (already retired), return empty array
        if (monthsToInclude <= 0) {
            return [];
        }
        
        // Create the extended data array
        const extendedData = [];
        
        // First include all original data
        for (let i = 0; i < data.length; i++) {
            extendedData.push(data[i]);
        }
        
        // If we need more entries, use the last month's data to fill the remaining months
        if (extendedData.length > 0) {
            const lastMonth = extendedData[extendedData.length - 1];
            
            // Use last month's data to fill remaining months
            while (extendedData.length < monthsToInclude) {
                // Create a new entry based on the last month's data
                const newEntry = {
                    month: `Month ${extendedData.length + 1}`,
                    details: JSON.parse(JSON.stringify(lastMonth.details))
                };
                
                extendedData.push(newEntry);
            }
        }
        
        // Trim to exactly monthsToInclude if we have more
        return extendedData.slice(0, monthsToInclude);
    },
    
    /**
     * Calculate average values from employee data
     * @param {Array} data - Employee data
     * @returns {Object} - Average values
     */
    calculateAverage: function(data) {
        if (!data || !data.length) {
            return {};
        }
        
        // Initialize an object to hold sums
        const sums = {};
        const firstEntry = data[0].details;
        
        // Initialize with non-numeric values from the first entry
        const result = {
            name: firstEntry.name,
            rank: firstEntry.rank,
            pan: firstEntry.pan
        };
        
        // Sum all numeric fields
        data.forEach(entry => {
            const details = entry.details;
            
            // Add each numeric field to the sums
            Object.keys(details).forEach(key => {
                const value = details[key];
                if (typeof value === 'number') {
                    sums[key] = (sums[key] || 0) + value;
                }
            });
        });
        
        // Calculate averages
        Object.keys(sums).forEach(key => {
            result[key] = sums[key] / data.length;
        });
        
        return result;
    },
    
    /**
     * Export tax reports to CSV format
     * @param {Array} reports - Tax reports
     * @returns {string} - CSV content
     */
    exportToCSV: function(reports) {
        if (!reports || !reports.length) {
            return '';
        }
        
        // Define CSV headers
        const headers = [
            'Regiment No', 'Name', 'Rank', 'PAN',
            'Gross Salary', 'Manual Claims', 'Manual Recovery',
            'Gross Income', 'Standard Deduction', 'Taxable Income',
            'Tax Before Rebate', 'Tax Rebate', 'Tax After Rebate',
            'Health & Education Cess', 'Marginal Relief', 'Tax Deductions', 'Net Tax Payable'
        ];
        
        let csvContent = headers.join(',') + '\n';
        
        // Add data rows
        reports.forEach(report => {
            const row = [
                `"${report.regtNo}"`,
                `"${report.name}"`,
                `"${report.rank}"`,
                `"${report.pan}"`,
                report.grossSalary,
                report.manualClaims,
                report.manualRecovery,
                report.grossIncome,
                report.standardDeduction,
                report.taxableIncome,
                report.taxDetails.taxBeforeRebate,
                report.taxDetails.rebate,
                report.taxDetails.taxAfterRebate,
                report.taxDetails.cess,
                report.taxDetails.marginalRelief,
                report.taxDeductions,
                report.taxDetails.netTax
            ];
            
            csvContent += row.join(',') + '\n';
        });
        
        return csvContent;
    },
    
    /**
     * Export tax reports to Excel format using SheetJS
     * @param {Array} reports - Tax reports
     * @returns {Object} - SheetJS workbook
     */
    exportToExcel: function(reports) {
        if (!reports || !reports.length || typeof XLSX === 'undefined') {
            console.error('XLSX library not available or no data to export');
            return null;
        }
        
        // Create a workbook
        const wb = XLSX.utils.book_new();
        
        // Data for the summary sheet
        const summaryData = reports.map(report => {
            return {
                'Regiment No': report.regtNo,
                'Name': report.name,
                'Rank': report.rank,
                'PAN': report.pan,
                'Retirement Date': report.retirementDate || 'N/A',
                'Gross Salary': report.grossSalary,
                'Manual Claims': report.manualClaims,
                'Manual Recovery': report.manualRecovery,
                'Gross Income': report.grossIncome,
                'Standard Deduction': report.standardDeduction,
                'Taxable Income': report.taxableIncome,
                'Tax Before Rebate': report.taxDetails.taxBeforeRebate,
                'Tax Rebate': report.taxDetails.rebate,
                'Tax After Rebate': report.taxDetails.taxAfterRebate,
                'Health & Education Cess': report.taxDetails.cess,
                'Marginal Relief': report.taxDetails.marginalRelief,
                'Tax Deductions': report.taxDeductions,
                'Net Tax Payable': report.taxDetails.netTax,
                'Monthly Tax': Math.ceil(report.taxDetails.netTax / 12)
            };
        });
        
        // Add the summary sheet
        const ws = XLSX.utils.json_to_sheet(summaryData);
        XLSX.utils.book_append_sheet(wb, ws, 'Tax Summary');
        
        // Add individual sheets for each employee with monthly breakdown
        reports.forEach(report => {
            const monthlyData = report.monthlyBreakdown.map((month, index) => {
                return {
                    'Month': month.month,
                    'Gross Salary': month.grossSalary,
                    'Tax Deducted': month.taxDeducted,
                };
            });
            
            // Add slabwise breakdown
            const slabwiseData = report.taxDetails.slabwiseTax.map((slab, index) => {
                return {
                    'Slab': `${index === 0 ? 'Up to' : 'From'} ${slab.slab.toLocaleString('en-IN')}`,
                    'Rate': `${(slab.rate * 100).toFixed(1)}%`,
                    'Taxable Amount': slab.taxable,
                    'Tax': slab.tax
                };
            });
            
            // Create employee sheet
            const employeeWS = XLSX.utils.json_to_sheet(monthlyData);
            
            // Add a gap and then add slabwise data
            const slabwiseWS = XLSX.utils.json_to_sheet(slabwiseData);
            
            // Append both to the workbook
            XLSX.utils.book_append_sheet(wb, employeeWS, `${report.regtNo}-Monthly`);
            XLSX.utils.book_append_sheet(wb, slabwiseWS, `${report.regtNo}-Slabs`);
        });
        
        return wb;
    }
};
