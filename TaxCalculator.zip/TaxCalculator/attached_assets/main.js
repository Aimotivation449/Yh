document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('sidebar');
    const toggleBtn = document.getElementById('toggleBtn');
    const menuItems = document.querySelectorAll('.menu-item');

    // Toggle Sidebar
    toggleBtn.addEventListener('click', () => {
        const isMobile = window.innerWidth <= 768;
        if (isMobile) {
            sidebar.classList.toggle('show');
        } else {
            sidebar.classList.toggle('collapsed');
        }
    });

    // Menu Navigation
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            // Remove active class from all items
            menuItems.forEach(i => i.classList.remove('active'));

            // Add active class to clicked item
            this.classList.add('active');

            // Get the page to navigate to
            const page = this.getAttribute('data-page');

            // Navigate to the page
            if (page) {
                if (page.startsWith('../')) {
                    window.location.href = page.substring(3);
                } else {
                    window.location.href = page;
                }
            }
        });
    });

    // Set active menu item based on current page
    const currentPath = window.location.pathname;
    const currentPage = currentPath.substring(currentPath.lastIndexOf('/') + 1) || 'index.html';

    menuItems.forEach(item => {
        const itemPage = item.getAttribute('data-page');
        if (itemPage === currentPage || itemPage === '../' + currentPage) {
            item.classList.add('active');
        }
    });
});

// Utility functions that may be needed across multiple pages

/**
 * Format currency in Indian Rupee format
 * @param {number} amount - The amount to format
 * @returns {string} - Formatted currency string
 */
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

/**
 * Safe parsing of a number from various formats
 * @param {any} value - The value to parse
 * @returns {number} - The parsed number or 0 if invalid
 */
function safeParseNumber(value) {
    if (typeof value === 'number') return value;
    const cleaned = String(value).replace(/,/g, '').replace(/[^0-9.-]/g, '');
    const parsed = parseFloat(cleaned);
    return isNaN(parsed) ? 0 : parsed;
}

/**
 * Calculate tax based on the income using the new tax regime
 * @param {number} income - The taxable income
 * @returns {number} - Calculated tax amount
 */
function calculateTax(income) {
    if (income <= 0) return 0;
    
    const slabs = [
        { min: 0, max: 400000, rate: 0 },
        { min: 400000, max: 800000, rate: 0.05 },
        { min: 800000, max: 1200000, rate: 0.10 },
        { min: 1200000, max: 1600000, rate: 0.15 },
        { min: 1600000, max: 2000000, rate: 0.20 },
        { min: 2000000, max: 2400000, rate: 0.25 },
        { min: 2400000, rate: 0.30 }
    ];
    
    let tax = 0;
    for (const slab of slabs) {
        if (income > slab.min) {
            const upper = slab.max || Infinity;
            const taxableInSlab = Math.min(income, upper) - slab.min;
            tax += taxableInSlab * slab.rate;
        }
    }
    
    // Apply 87A rebate - 60000 for income up to 1200000 (12 Lakh)
    const taxCredit = income <= 1200000 ? Math.min(tax, 60000) : 0;
    const netTax = Math.max(tax - taxCredit, 0);
    const cess = netTax * 0.04;
    
    return {
        taxableIncome: income,
        totalTax: tax,
        taxCredit: taxCredit,
        netTax: netTax,
        cess: cess,
        grossTax: netTax + cess
    };
}
    

// Calculate marginal relief for income just above 700000
if (income > 700000 && income <= 750000) {
    // Calculate tax without 87A rebate
    const normalTax = tax;
    
    // Calculate tax at 700000 with 87A rebate
    const taxAt700k = calculateTax(700000);
    
    // Calculate marginal relief
    const additionalIncome = income - 700000;
    const additionalTax = normalTax - taxAt700k;
    
    if (additionalTax > additionalIncome) {
        // Provide marginal relief so that additional tax doesn't exceed additional income
        tax = taxAt700k + additionalIncome;
    }
}
    

return Math.round(tax);
}

/**
 * Parse date string into a proper Date object
 * @param {string} dateStr - Date string in various formats
 * @returns {Date|null} - Date object or null if invalid
 */
function parseDate(dateStr) {
    if (!dateStr) return null;
    
    // Try different date formats
    const date = new Date(dateStr);
    if (!isNaN(date.getTime())) return date;
    
    // Try DD/MM/YYYY format
    const parts = dateStr.split(/[/.-]/);
    if (parts.length === 3) {
        // Check if first part is likely a day (1-31)
        if (parseInt(parts[0]) <= 31) {
            return new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
        }
        // Check if first part is likely a year (>31)
        if (parseInt(parts[0]) > 31) {
            return new Date(`${parts[0]}-${parts[1]}-${parts[2]}`);
        }
    }
    
    return null;
}

/**
 * Calculate marginal relief for incomes just above tax exemption limit
 * @param {number} income - Taxable income
 * @param {number} tax - Calculated tax
 * @returns {number} - Marginal relief amount
 */
function calculateMarginalRelief(income, tax) {
    if (income <= 700000) return 0;
    
    if (income > 700000 && income <= 750000) {
        // Calculate tax for 700000
        const taxAt700k = calculateTax(700000);
        
        // Additional income above 700000
        const additionalIncome = income - 700000;
        
        // Additional tax above 700000
        const additionalTax = tax - taxAt700k;
        
        // If additional tax is more than additional income, provide relief
        if (additionalTax > additionalIncome) {
            return additionalTax - additionalIncome;
        }
    }
    
    return 0;
}

/**
 * Extend employee data to cover 12 months or until retirement date
 * @param {Array} employee - The employee data array
 * @param {string|Date} retirementDate - Optional retirement date
 * @returns {Array} - Extended employee data
 */
function extendTo12Months(employee, retirementDate = null) {
    if (!employee || employee.length === 0) return [];
    
    // Clone the employee data to avoid modifying the original
    const result = JSON.parse(JSON.stringify(employee));
    
    // Get the fiscal year dates
    const today = new Date();
    const fiscalYearStart = new Date(today.getFullYear(), 3, 1); // April 1st of current year
    if (today < fiscalYearStart) {
        fiscalYearStart.setFullYear(fiscalYearStart.getFullYear() - 1); // Previous year's April
    }
    const fiscalYearEnd = new Date(fiscalYearStart);
    fiscalYearEnd.setFullYear(fiscalYearStart.getFullYear() + 1);
    fiscalYearEnd.setDate(0); // Last day of March next year
    
    // Check if retirement date is valid
    let retireDate = null;
    
    if (retirementDate) {
        retireDate = typeof retirementDate === 'string' 
            ? parseDate(retirementDate) 
            : retirementDate;
    }
    
    // If retirement date is valid
    if (retireDate && !isNaN(retireDate.getTime())) {
        // If retirement date is before fiscal year start, they're already retired
        if (retireDate < fiscalYearStart) {
            return [];
        }
        
        // If retirement date is within the fiscal year
        if (retireDate <= fiscalYearEnd) {
            // Calculate months from fiscal year start to retirement
            const monthsActive = (
                (retireDate.getFullYear() - fiscalYearStart.getFullYear()) * 12 + 
                retireDate.getMonth() - fiscalYearStart.getMonth() + 
                (retireDate.getDate() >= 15 ? 1 : 0) // Count current month if retiring after 15th
            );
            
            // Ensure at least one month if retiring in April
            const effectiveMonths = Math.max(1, monthsActive);
            
            // Use the last available month's data to fill the remaining months
            const lastMonth = result[result.length - 1];
            
            // Fill up to retirement month
            while (result.length < effectiveMonths) {
                result.push(JSON.parse(JSON.stringify(lastMonth)));
            }
            
            return result.slice(0, effectiveMonths);
        }
    }
    
    // Use the last available month's data to fill the remaining months
    const lastMonth = result[result.length - 1];
    
    // Fill up to 12 months if no retirement or retirement is in next fiscal year
    while (result.length < 12) {
        result.push(JSON.parse(JSON.stringify(lastMonth)));
    }
    
    return result.slice(0, 12); // Ensure we return at most 12 months
}