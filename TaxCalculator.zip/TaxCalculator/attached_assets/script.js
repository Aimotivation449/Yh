// Global variables to store data
let csvData = [];
let uniqueData = [];
let salaryDataMap = {}; // For storing salary data in localStorage

// Function to handle file upload
function uploadFile() {
    const fileInput = document.getElementById('csvFile');
    const file = fileInput.files[0];

    if (file) {
        // Determine file type
        const fileType = file.name.split('.').pop().toLowerCase();
        
        if (fileType === 'csv') {
            Papa.parse(file, {
                header: false,
                skipEmptyLines: true,
                complete: function(results) {
                    csvData = results.data.slice(1); // Skip header row
                    processSalaryData();
                },
                error: function(error) {
                    console.error("Error parsing CSV:", error);
                    alert("There was an error uploading the file. Please try again.");
                }
            });
        } else if (fileType === 'xlsx') {
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, { type: 'array' });
                    const firstSheet = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[firstSheet];
                    
                    // Convert to array of arrays (skip header)
                    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                    csvData = jsonData.slice(1); // Skip header row
                    processSalaryData();
                } catch (error) {
                    console.error("Error processing XLSX:", error);
                    alert("There was an error processing the Excel file. Please try again.");
                }
            };
            reader.onerror = function() {
                alert("Error reading the file. Please try again.");
            };
            reader.readAsArrayBuffer(file);
        } else {
            alert("Unsupported file type. Please upload a CSV or XLSX file.");
        }
    } else {
        alert("Please select a file to upload.");
    }
}

// Process salary data and save to localStorage
function processSalaryData() {
    if (!validateCSV(csvData)) {
        alert("The uploaded file format is invalid. Please check the file structure and try again.");
        return;
    }
    
    filterUniqueRows();
    saveSalaryData();
    alert("File uploaded successfully!");
    displayTable(uniqueData);
}

// Function to filter unique rows based on Regiment Number
function filterUniqueRows() {
    const seen = new Set();
    uniqueData = csvData.filter(row => {
        const regtNo = row[0];
        if (!regtNo || seen.has(regtNo)) {
            return false;
        }
        seen.add(regtNo);
        return true;
    });
}

// Save salary data to localStorage
function saveSalaryData() {
    try {
        // Group data by regiment number
        const dataByRegtNo = {};
        
        // Process each row in CSV data
        csvData.forEach(row => {
            if (!row[0]) return; // Skip rows without regiment number
            
            const regtNo = row[0];
            const month = row[8] || ''; // Column I for month
            
            if (!dataByRegtNo[regtNo]) {
                dataByRegtNo[regtNo] = [];
            }
            
            // Create detailed entry
            const entry = {
                month: month,
                details: {
                    rank: row[2] || '',
                    name: row[4] || '',
                    pan: row[7] || '',
                    basicPay: safeParseNumber(row[9]),
                    da: safeParseNumber(row[11]),
                    tpt: safeParseNumber(row[12]),
                    hra: safeParseNumber(row[13]),
                    dressAll: safeParseNumber(row[14]),
                    nurseDressAll: safeParseNumber(row[15]),
                    bonus: safeParseNumber(row[16]),
                    rma: safeParseNumber(row[17]),
                    daArrear: safeParseNumber(row[18]),
                    familyPay: safeParseNumber(row[19]),
                    personalPay: safeParseNumber(row[20]),
                    soapAll: safeParseNumber(row[21]),
                    hindiPay: safeParseNumber(row[22]),
                    specialPay: safeParseNumber(row[23]),
                    hca: safeParseNumber(row[24]),
                    hpca: safeParseNumber(row[25]),
                    rha: safeParseNumber(row[26]),
                    sdaCa: safeParseNumber(row[27]),
                    rumCigaretteAll: safeParseNumber(row[28]),
                    total: safeParseNumber(row[29]),
                    gpf: safeParseNumber(row[30]),
                    cpf: safeParseNumber(row[31]),
                    cgegis: safeParseNumber(row[32]),
                    cghs: safeParseNumber(row[33]),
                    gjspkk: safeParseNumber(row[34]),
                    tax: safeParseNumber(row[35]),
                    hrr: safeParseNumber(row[36]),
                    pli: safeParseNumber(row[37]),
                    recovery: safeParseNumber(row[39])
                }
            };
            
            dataByRegtNo[regtNo].push(entry);
        });
        
        // Save to local storage
        localStorage.setItem('salaryData', JSON.stringify(dataByRegtNo));
        salaryDataMap = dataByRegtNo;
    } catch (error) {
        console.error("Error saving salary data:", error);
        alert("There was an error saving the data. Please try again.");
    }
}

// Safe parsing for number values
function safeParseNumber(value) {
    if (typeof value === 'number') return value;
    if (!value) return 0;
    
    const cleaned = String(value).replace(/,/g, '').replace(/[^0-9.-]/g, '');
    const parsed = parseFloat(cleaned);
    return isNaN(parsed) ? 0 : parsed;
}

// Function to handle search
function search() {
    const searchType = document.getElementById('searchType').value;
    const searchInput = document.getElementById('searchInput').value.trim().toLowerCase();
    
    if (!searchInput) {
        displayTable(uniqueData);
        return;
    }
    
    let filteredData;
    if (searchType === 'regno') {
        filteredData = uniqueData.filter(row => row[0].toLowerCase().includes(searchInput));
    } else { // name search
        filteredData = uniqueData.filter(row => (row[4] || '').toLowerCase().includes(searchInput));
    }
    
    displayTable(filteredData);
}

// Function to calculate average salary and other details for tax purposes
function calculateEmployeeData() {
    // Load bill claims
    let billClaims = [];
    try {
        const storedClaims = localStorage.getItem('billClaims');
        if (storedClaims) {
            billClaims = JSON.parse(storedClaims);
        }
    } catch (error) {
        console.error('Error loading bill claims:', error);
    }
    
    // Calculate average salary and process manual claims
    const employeeData = {};
    
    // Process monthly salary data first
    uniqueData.forEach(row => {
        const regtNo = row[0];
        if (!regtNo) return;
        
        // Find all matching rows in the full dataset
        const allEntries = csvData.filter(r => r[0] === regtNo);
        
        // Calculate average monthly salary
        let totalSalary = 0;
        allEntries.forEach(entry => {
            totalSalary += safeParseNumber(entry[29]); // Column AD for salary
        });
        
        const avgMonthlySalary = allEntries.length > 0 ? totalSalary / allEntries.length : 0;
        const annualSalary = Math.round(avgMonthlySalary * 12);
        
        // Get retirement date if set
        let retirementDate = null;
        try {
            retirementDate = localStorage.getItem(`retirement_${regtNo}`);
        } catch (error) {
            console.error(`Error loading retirement date for ${regtNo}:`, error);
        }
        
        // Calculate months of service this fiscal year
        let monthsOfService = 12;
        if (retirementDate) {
            const retDate = parseDate(retirementDate);
            if (retDate) {
                const fiscalYearStart = new Date();
                fiscalYearStart.setMonth(3); // April is month 3 (0-indexed)
                fiscalYearStart.setDate(1); // 1st of April
                
                const fiscalYearEnd = new Date(fiscalYearStart);
                fiscalYearEnd.setFullYear(fiscalYearStart.getFullYear() + 1);
                fiscalYearEnd.setDate(0); // Last day of March
                
                if (retDate >= fiscalYearStart && retDate <= fiscalYearEnd) {
                    // Calculate months between April 1 and retirement date
                    monthsOfService = (retDate.getMonth() - 3 + 12) % 12 + 1;
                } else if (retDate < fiscalYearStart) {
                    monthsOfService = 0;
                }
            }
        }
        
        // Process manual claims for this employee
        const empClaims = billClaims.filter(claim => claim.regtNo === regtNo);
        
        const additionalTaxableIncome = empClaims
            .filter(claim => claim.billType !== 'Recovery' && claim.billType !== 'Tax Deduction' && claim.taxable)
            .reduce((sum, claim) => sum + claim.amount, 0);
            
        const recoveries = empClaims
            .filter(claim => claim.billType === 'Recovery')
            .reduce((sum, claim) => sum + claim.amount, 0);
            
        const manualTaxDeductions = empClaims
            .filter(claim => claim.billType === 'Tax Deduction')
            .reduce((sum, claim) => sum + claim.amount, 0);
        
        // Apply standard deduction
        const standardDeduction = 75000;
        
        // Calculate pro-rated salary if retiring this year
        const proRatedSalary = monthsOfService < 12 ? Math.round(avgMonthlySalary * monthsOfService) : annualSalary;
        
        // Calculate taxable income
        const taxableIncome = proRatedSalary + additionalTaxableIncome - recoveries - standardDeduction;
        
        // Calculate tax
        const tax = calculateTax(Math.max(0, taxableIncome));
        const educationCess = Math.round(tax * 0.04);
        const totalTax = Math.max(0, tax + educationCess - manualTaxDeductions);
        
        // Store data
        employeeData[regtNo] = {
            rank: row[2] || '',
            name: row[4] || '',
            totalSalary: proRatedSalary,
            standardDeduction: standardDeduction,
            additionalIncome: additionalTaxableIncome,
            recoveries: recoveries,
            taxableIncome: Math.max(0, taxableIncome),
            tax: tax,
            educationCess: educationCess,
            manualTaxDeductions: manualTaxDeductions,
            totalTax: totalTax,
            monthsOfService: monthsOfService,
            monthlyDeduction: monthsOfService > 0 ? Math.round(totalTax / monthsOfService) : 0
        };
    });
    
    return employeeData;
}

// Function to display table with calculated values
function displayTable(data) {
    const resultDiv = document.getElementById('result');
    
    if (!data || data.length === 0) {
        resultDiv.innerHTML = '<p>No data available to display.</p>';
        return;
    }
    
    const employeeData = calculateEmployeeData();
    
    let tableHTML = `
        <table border="1">
            <tr>
                <th>Regt. No.</th>
                <th>Rank</th>
                <th>Name</th>
                <th>Total Salary</th>
                <th>Standard Deduction</th>
                <th>Add. Income</th>
                <th>Recoveries</th>
                <th>Taxable Income</th>
                <th>Tax (New Regime)</th>
                <th>Education Cess</th>
                <th>Manual Tax Ded.</th>
                <th>Total Tax for FY</th>
                <th>Monthly Deduction</th>
            </tr>`;

    data.forEach(row => {
        const regtNo = row[0];
        if (!regtNo || !employeeData[regtNo]) return;
        
        const empData = employeeData[regtNo];
        
        tableHTML += `
            <tr class="data-row">
                <td>${regtNo}</td>
                <td>${empData.rank}</td>
                <td>${empData.name}</td>
                <td>${empData.totalSalary.toLocaleString()}</td>
                <td>${empData.standardDeduction.toLocaleString()}</td>
                <td>${empData.additionalIncome.toLocaleString()}</td>
                <td>${empData.recoveries.toLocaleString()}</td>
                <td>${empData.taxableIncome.toLocaleString()}</td>
                <td>${empData.tax.toLocaleString()}</td>
                <td>${empData.educationCess.toLocaleString()}</td>
                <td>${empData.manualTaxDeductions.toLocaleString()}</td>
                <td>${empData.totalTax.toLocaleString()}</td>
                <td>${empData.monthlyDeduction.toLocaleString()}</td>
            </tr>`;
    });

    tableHTML += '</table>';
    resultDiv.innerHTML = tableHTML;
}

// Function to export data to Excel
function exportToExcel() {
    const resultDiv = document.getElementById('result');
    const table = resultDiv.querySelector('table');

    if (!table) {
        alert("No data available to export.");
        return;
    }

    const wb = XLSX.utils.table_to_book(table, { sheet: "Tax_Calculation" });
    XLSX.writeFile(wb, 'Tax_Calculation_Report.xlsx');
}

// Function to show help modal
function showHelp() {
    const modal = document.getElementById('helpModal');
    modal.style.display = "block";
}

// Function to clear all data and reset form
function clearAll() {
    document.getElementById('csvFile').value = '';
    document.getElementById('searchInput').value = '';
    document.getElementById('searchType').selectedIndex = 0;
    document.getElementById('result').innerHTML = '';
    csvData = [];
    uniqueData = [];
}

// Function to handle printing
function printResults() {
    window.print();
}

// Function to validate CSV structure
function validateCSV(data) {
    if (!data || data.length === 0) {
        return false;
    }
    
    // Check for minimum required columns
    const requiredColumns = 30; // Assuming we need 30 columns including salary in AD
    
    for (const row of data) {
        if (row.length < requiredColumns) {
            return false;
        }
        
        // Validate Regiment Number
        if (!row[0] || row[0].trim() === '') {
            return false;
        }
    }
    
    return true;
}

// Load data from localStorage on page load
document.addEventListener('DOMContentLoaded', function() {
    // Search event listeners
    const searchInput = document.getElementById('searchInput');
    const searchType = document.getElementById('searchType');
    
    searchInput.addEventListener('input', search);
    searchType.addEventListener('change', search);

    // Modal close handlers
    const modal = document.getElementById('helpModal');
    const closeBtn = document.getElementsByClassName("close")[0];
    
    closeBtn.onclick = function() {
        modal.style.display = "none";
    }

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', function(event) {
        if (event.key === "Escape") {
            modal.style.display = "none";
        }
        // Add more keyboard shortcuts if needed
        if (event.ctrlKey && event.key === 'p') {
            event.preventDefault();
            window.print();
        }
    });
    
    // Try to load saved data
    try {
        const storedData = localStorage.getItem('salaryData');
        if (storedData) {
            salaryDataMap = JSON.parse(storedData);
            
            // Convert stored data back to rows for display
            csvData = [];
            uniqueData = [];
            
            for (const regtNo in salaryDataMap) {
                const entries = salaryDataMap[regtNo];
                if (entries && entries.length > 0) {
                    entries.forEach(entry => {
                        const details = entry.details;
                        const row = Array(40).fill(''); // Create empty row with 40 columns
                        
                        // Fill in the data we have
                        row[0] = regtNo;
                        row[2] = details.rank;
                        row[4] = details.name;
                        row[7] = details.pan;
                        row[8] = entry.month;
                        row[9] = details.basicPay;
                        row[11] = details.da;
                        row[12] = details.tpt;
                        row[13] = details.hra;
                        row[14] = details.dressAll;
                        row[15] = details.nurseDressAll;
                        row[16] = details.bonus;
                        row[17] = details.rma;
                        row[18] = details.daArrear;
                        row[19] = details.familyPay;
                        row[20] = details.personalPay;
                        row[21] = details.soapAll;
                        row[22] = details.hindiPay;
                        row[23] = details.specialPay;
                        row[24] = details.hca;
                        row[25] = details.hpca;
                        row[26] = details.rha;
                        row[27] = details.sdaCa;
                        row[28] = details.rumCigaretteAll;
                        row[29] = details.total;
                        row[30] = details.gpf;
                        row[31] = details.cpf;
                        row[32] = details.cgegis;
                        row[33] = details.cghs;
                        row[34] = details.gjspkk;
                        row[35] = details.tax;
                        row[36] = details.hrr;
                        row[37] = details.pli;
                        row[39] = details.recovery;
                        
                        csvData.push(row);
                    });
                    
                    // Add first entry of each regtNo to uniqueData
                    const firstEntry = salaryDataMap[regtNo][0];
                    const uniqueRow = Array(40).fill('');
                    uniqueRow[0] = regtNo;
                    uniqueRow[2] = firstEntry.details.rank;
                    uniqueRow[4] = firstEntry.details.name;
                    uniqueRow[29] = firstEntry.details.total;
                    
                    uniqueData.push(uniqueRow);
                }
            }
            
            if (uniqueData.length > 0) {
                displayTable(uniqueData);
            }
        }
    } catch (e) {
        console.error('Error loading saved data:', e);
    }
});
