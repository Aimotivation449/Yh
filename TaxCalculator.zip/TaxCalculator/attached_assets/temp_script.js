// Global variables to store data
let csvData = [];
let uniqueData = [];

// Function to handle file upload
function uploadFile() {
    const fileInput = document.getElementById('csvFile');
    const file = fileInput.files[0];

    if (file) {
        Papa.parse(file, {
            header: false,
            skipEmptyLines: true,
            complete: function(results) {
                csvData = results.data.slice(1); // Skip header row
                filterUniqueRows();
                alert("File uploaded successfully!");
                displayTable(uniqueData);
            },
            error: function(error) {
                console.error("Error parsing CSV:", error);
                alert("There was an error uploading the file. Please try again.");
            }
        });
    } else {
        alert("Please select a file to upload.");
    }
}

// Function to filter unique rows based on Regiment Number
function filterUniqueRows() {
    const seen = new Set();
    uniqueData = csvData.filter(row => {
        const regtNo = row[0];
        if (seen.has(regtNo)) {
            return false;
        }
        seen.add(regtNo);
        return true;
    });
}

// Function to handle search
function search() {
    const searchType = document.getElementById('searchType').value;
    const searchInput = document.getElementById('searchInput').value.trim().toLowerCase();
    
    let filteredData;
    if (searchType === 'regno') {
        filteredData = uniqueData.filter(row => row[0].toLowerCase().includes(searchInput));
    } else { // name search
        filteredData = uniqueData.filter(row => row[4].toLowerCase().includes(searchInput));
    }
    
    displayTable(filteredData);
}

// Function to calculate average salary
function calculateAverageSalary() {
    const regtNoSalaryMap = {};
    const regtNoCountMap = {};

    csvData.forEach(row => {
        const regtNo = row[0];
        const salary = parseFloat(row[29]) || 0; // Column AD for salary

        if (!regtNoSalaryMap[regtNo]) {
            regtNoSalaryMap[regtNo] = 0;
            regtNoCountMap[regtNo] = 0;
        }

        regtNoSalaryMap[regtNo] += salary;
        regtNoCountMap[regtNo]++;
    });

    // Calculate annual salary
    for (const regtNo in regtNoSalaryMap) {
        const averageMonthlySalary = regtNoSalaryMap[regtNo] / regtNoCountMap[regtNo];
        regtNoSalaryMap[regtNo] = Math.round(averageMonthlySalary * 12);
    }

    return regtNoSalaryMap;
}

// Function to calculate tax based on new regime
function calculateTax(income) {
    const slabs = [
        { limit: 300000, rate: 0 },
        { limit: 400000, rate: 0.05 },
        { limit: 300000, rate: 0.1 },
        { limit: 200000, rate: 0.15 },
        { limit: 300000, rate: 0.2 },
        { limit: Infinity, rate: 0.3 }
    ];

    let tax = 0;
    let remainingIncome = income;

    for (const slab of slabs) {
        if (remainingIncome <= 0) break;
        
        const taxableInThisSlab = Math.min(remainingIncome, slab.limit);
        tax += taxableInThisSlab * slab.rate;
        remainingIncome -= slab.limit;
    }

    // Apply rebate under section 87A - 60000 for income up to 1200000 (12 Lakh)
    if (income <= 1200000) {
        tax = Math.max(0, tax - 60000);
    }

    return Math.round(tax);
}

// Function to display table with calculated values
function displayTable(data) {
    const resultDiv = document.getElementById('result');
    let tableHTML = `
        <table border="1">
            <tr>
                <th>Regt. No.</th>
                <th>Rank</th>
                <th>Name</th>
                <th>Total Salary</th>
                <th>Standard Deduction</th>
                <th>Taxable Income</th>
                <th>Tax (New Regime)</th>
                <th>Education Cess</th>
                <th>Total Tax for FY</th>
            </tr>`;

    const totalSalaryData = calculateAverageSalary();

    data.forEach(row => {
        const regtNo = row[0];
        const rank = row[2];
        const name = row[4];
        const totalSalary = totalSalaryData[regtNo];
        const standardDeduction = 75000;
        const taxableIncome = totalSalary - standardDeduction;
        let tax = calculateTax(taxableIncome);
        let educationCess = Math.round(tax * 0.04);

        if (tax < 0) {
            tax = 0;
            educationCess = 0;
        }

        const totalTax = tax + educationCess;

        tableHTML += `
            <tr class="data-row">
                <td>${regtNo}</td>
                <td>${rank}</td>
                <td>${name}</td>
                <td>${totalSalary.toLocaleString()}</td>
                <td>${standardDeduction.toLocaleString()}</td>
                <td>${taxableIncome.toLocaleString()}</td>
                <td>${tax.toLocaleString()}</td>
                <td>${educationCess.toLocaleString()}</td>
                <td>${totalTax.toLocaleString()}</td>
            </tr>`;
    });

    tableHTML += '</table>';
    resultDiv.innerHTML = tableHTML;
}

// Function to export data to Excel
function exportToExcel() {
    const resultDiv = document.getElementById('result');
    const table = resultDiv.querySelector('table');

    if (!table) {
        alert("No data available to export.");
        return;
    }

    const wb = XLSX.utils.table_to_book(table, { sheet: "Tax_Calculation" });
    XLSX.writeFile(wb, 'Tax_Calculation_Report.xlsx');
}

// Function to show help modal
function showHelp() {
    const modal = document.getElementById('helpModal');
    modal.style.display = "block";
}

// Function to clear all data and reset form
function clearAll() {
    document.getElementById('csvFile').value = '';
    document.getElementById('searchInput').value = '';
    document.getElementById('searchType').selectedIndex = 0;
    document.getElementById('result').innerHTML = '';
    csvData = [];
    uniqueData = [];
}

// Function to format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Search event listeners
    const searchInput = document.getElementById('searchInput');
    const searchType = document.getElementById('searchType');
    
    searchInput.addEventListener('input', search);
    searchType.addEventListener('change', search);

    // Modal close handlers
    const modal = document.getElementById('helpModal');
    const closeBtn = document.getElementsByClassName("close")[0];
    
    closeBtn.onclick = function() {
        modal.style.display = "none";
    }

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', function(event) {
        if (event.key === "Escape") {
            modal.style.display = "none";
        }
        // Add more keyboard shortcuts if needed
        if (event.ctrlKey && event.key === 'p') {
            event.preventDefault();
            window.print();
        }
    });
});

// Function to handle printing
function printResults() {
    window.print();
}

// Function to validate CSV structure
function validateCSV(data) {
    if (!data || data.length === 0) {
        return false;
    }
    
    // Check for minimum required columns
    const requiredColumns = 30; // Assuming we need 30 columns including salary in AD
    
    for (const row of data) {
        if (row.length < requiredColumns) {
            return false;
        }
        
        // Validate Regiment Number
        if (!row[0] || row[0].trim() === '') {
            return false;
        }
        
        // Validate Salary (column AD - index 29)
        const salary = parseFloat(row[29]);
        if (isNaN(salary) || salary < 0) {
            return false;
        }
    }
    
    return true;
}

// Error handling wrapper
function handleError(fn) {
    return function(...args) {
        try {
            return fn.apply(this, args);
        } catch (error) {
            console.error('An error occurred:', error);
            alert('An error occurred. Please try again or contact support if the problem persists.');
            return null;
        }
    };
}

document.addEventListener('DOMContentLoaded', function() {
    // Try to load saved data
    const savedData = localStorage.getItem('salaryData');
    if (savedData) {
        try {
            allData = JSON.parse(savedData);
            generateOutput();
        } catch (e) {
            console.error('Error loading saved data:', e);
        }
    }
});

// Wrap major functions with error handling
const safeUpload = handleError(uploadFile);
const safeExport = handleError(exportToExcel);
const safePrint = handleError(printResults);